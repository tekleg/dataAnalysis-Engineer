package projectFive;
//Paint.java
//Paint.java
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;
public class Paint extends JPanel{

	 // declare the required variables
	   private boolean lineBeingDrawn;
	   private Point startingPoint;
	   private ArrayList<PointsWithColor> coordinateList;
	   private Color selectedColor;
	   private PointsWithColor pwc;
	   // Constructor of the Panel Paint2
	   public Paint()
	   {
	        // set the Background
	        setBackground(Color.white);
	       
	        // initialize the class variables
	        lineBeingDrawn = false;
	        startingPoint = new Point(0, 0);
	        selectedColor = Color.BLACK;
	        coordinateList = new ArrayList<PointsWithColor>();
	        
	        // add mouseListener and MouseMotionListeners
	        this.addMouseListener(new DrawingListener());
	        this.addMouseMotionListener(new DrawingListener());
	   }
	   
	   // paint method to draw as pen functionality
	   @Override
	   public void paintComponent(Graphics pen)
	   {
	        super.paintComponent(pen);
	       
	        // if(lineBeingDrawn)
	        for (PointsWithColor c : coordinateList)
	        {
	        	selectedColor = c.getColor();
	            pen.setColor(selectedColor);
	            pen.fillOval(c.getCoordinate().x,c.getCoordinate().y, 5, 5);
	        }
	   }
	  
	   // DrawingListener inner class which is of type mouse
	   // adapter
	   // class that contains mouseEvents
	   private class DrawingListener extends MouseAdapter
	   {
	        // when mouse is clicked, it starts drawing, at
	        // the same time, when clicked, stops drawing
	        @Override
	        public void mouseClicked(MouseEvent ev)
	        {
	            Point clickedPoint = ev.getPoint();
	            if (!lineBeingDrawn)
	            {
	                 startingPoint = clickedPoint;
	                 repaint();
	            }
	            lineBeingDrawn = !lineBeingDrawn;
	            repaint();
	        }
	       
	        // when mouse is moved and mouse is clicked, then
	        // it starting drawing
	        @Override
	        public void mouseMoved(MouseEvent ev)
	        {
	        	if (lineBeingDrawn)
	            {
	                 Point p = ev.getPoint();
	                 PointsWithColor newPoint = new PointsWithColor(
	                           selectedColor, p);
	                 coordinateList.add(newPoint);
	            }
	            repaint();
	        }
	   }
	   
	   // setter and getter methods of the
	   public void setColor(Color color)
	   {
	        this.selectedColor = color;
	   }
	   public boolean isLineBeingDrawn()
	   {
	        return lineBeingDrawn;
	   }
	   public void setLineBeingDrawn(boolean lineBeingDrawn)
	   {
	        this.lineBeingDrawn = lineBeingDrawn;
	   }
	   public Point getStartingPoint()
	   {
	        return startingPoint;
	   }
	   public void setStartingPoint(Point startingPoint)
	   {
	        this.startingPoint = startingPoint;
	   }
	   public ArrayList<PointsWithColor> getCoordinateList()
	   {
	        return coordinateList;
	   }
	   public void
	setCoordinateList(ArrayList<PointsWithColor>
	coordinateList)
	   {
	        this.coordinateList = coordinateList;
	   }
	   public Color getSelectedColor()
	   {
	        return selectedColor;
	   }
	   public void setSelectedColor(Color selectedColor)
	   {
	        this.selectedColor = selectedColor;
	   }
	   // adds the new PointsWithColor objects to the
	//ArrayList
	   public void addCoordinateList(PointsWithColor pwc)
	   {
	        this.coordinateList.add(pwc);
	   }
	}

