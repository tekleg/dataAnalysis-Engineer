package projectFive;

//Painter.java
//Painter.java
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

public class Painter extends JFrame {

	// Declare the required variables
	private JButton blueButton, redButton, greenButton, eraserButton, clearButton;
	private Container myCP;
	public Paint panel;
	private JPanel mainContainer;

	public Painter() {
		
		// Create a new Panel and Set the layout
		mainContainer = new JPanel(new BorderLayout());
		mainContainer.setBackground(Color.WHITE);
		JPanel panel2 = new JPanel();
		
		// creates a JPanel
		panel2.setLayout(new FlowLayout());
		
		// This sets the size of the panel
		blueButton = new JButton("Blue");
		
		// blueButton.setPreferredSize(new Dimension(75,
		// 25));
		panel2.add(blueButton);
		blueButton.addActionListener(new ButtonListener());
		redButton = new JButton("Red");
		
		// redButton.setPreferredSize(new Dimension(75,
		// 25));
		panel2.add(redButton);
		redButton.addActionListener(new ButtonListener());
		greenButton = new JButton("Green");
		
		// greenButton.setPreferredSize(new Dimension(75,
		// 25));
		panel2.add(greenButton);
		greenButton.addActionListener(new ButtonListener());
		eraserButton = new JButton("Eraser");
		
		// eraserButton.setPreferredSize(new
		// Dimension(75, 25));
		panel2.add(eraserButton);
		eraserButton.addActionListener(new ButtonListener());
		clearButton = new JButton("Clear");
		
		// clearButton.setPreferredSize(new Dimension(75,
		// 25));
		panel2.add(clearButton);
		clearButton.addActionListener(new ButtonListener());

		// Create object to the panel Paint2
		panel = new Paint();
		// add both the panels to the JPanel
		mainContainer.add(panel2, BorderLayout.NORTH);
		mainContainer.add(panel, BorderLayout.CENTER);

		// add the mainContainer panel to the JFrame
		// container
		add(mainContainer);
		setVisible(true);
	}

	// button listener class that contains button events
	// operation upon user selection of buttons
	private class ButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			
			// to set the color of the pen to blue when
			// blueButton button is clicked
			if (e.getSource() == blueButton) {
				panel.addCoordinateList(new PointsWithColor(Color.BLUE, new Point()));
			}
			
			// to set the color of the pen to red when
			// redButton button is clicked
			if (e.getSource() == redButton) {
				panel.addCoordinateList(new PointsWithColor(Color.RED, new Point()));
			}

			// to set the color of the pen to green when
			// greenButton button is clicked
			if (e.getSource() == greenButton) {
				panel.addCoordinateList(new PointsWithColor(Color.GREEN, new Point()));
			}

			// to set the color of the according to
			// background color in-order to erase the
			// content when eraserButton is clicked
			if (e.getSource() == eraserButton) {
				panel.addCoordinateList(new PointsWithColor(panel.getBackground(), new Point()));
			}

			// to clear whole panel when clearButton is
			// clicked
			if (e.getSource() == clearButton) {
				panel.setCoordinateList(new ArrayList<PointsWithColor>());
				repaint();
			}
		}
	}

	// main method that creates object to the JFrame class
	// Painter
	public static void main(String args[]) {
		Painter myAppF = new Painter();

		// sets the visibility, title, size and close
		// operation of the frame
		myAppF.setTitle("Painter");
		myAppF.setVisible(true);
		myAppF.setSize(500, 500);
		myAppF.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
