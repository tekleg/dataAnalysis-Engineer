package projectFive;
import java.awt.Color;
import java.awt.Point;
public class PointsWithColor {
	 private Color pointColor;
     private Point coordinate;
     
     public PointsWithColor(Color color, Point coordinate)
     {
          this.pointColor = color;
          this.coordinate = coordinate;
     }
     public Color getColor()
     {
          return pointColor;
     }
     public void setColor(Color color)
     {
          this.pointColor = color;
     }
     public Point getCoordinate()
     {
          return coordinate;
     }
     public void setCoordinate(Point coordinate)
     {
          this.coordinate = coordinate;
     }
}



 