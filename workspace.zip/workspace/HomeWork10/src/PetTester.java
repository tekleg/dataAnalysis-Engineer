import java.util.ArrayList;

public class PetTester {

	public static void main(String[] args) {

		// Create an array to hold 6 Pet objects
		Pet[] myArray = new Pet[6];

		// Fill the array with some cats and some dogs.
		myArray[0] = new Dog("Fido1", 8, "10");
		myArray[1] = new Dog("Fido2", 6, "8");
		myArray[2] = new Dog("Fido3", 8, "10");
		myArray[2] = new Cat(" Biby1", 5, true);
		myArray[2] = new Cat(" Biby2", 6, false);
		myArray[2] = new Cat(" Biby3", 2, true);

		// Iterate the array and print a text representation of each pet.
		for (int i = 0; i < myArray.length; i++) {
			System.out.println(myArray[i].toString());
		}
		// Iterate the array and output the name of each outdoor cat.
		for (int i = 0; i < myArray.length; i++) {
			if (((Cat) myArray[i]).getIndoorCat() == false) {
				System.out.println("The outdoor cat are" + myArray[i]);
			}
		}

		// Sort the array by invoking a Java-provided sorting method.
		for (Pet myArr : myArray) {
			System.out.println(myArr.getName() + myArr.getAge());
		}
	}

}
