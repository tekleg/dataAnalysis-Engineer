
public class Dog extends Pet {
	// name,age are inherited from pet
	private String breed;

	public Dog(String name, int age, String breed) {
		super(name, age);
		this.breed = breed;
	}

	// getters and setters for name, age are inherited

	public String getBreed() {
		return breed;
	}

	public void setBreed(String bread) {
		this.breed = bread;
	}

	@Override
	public String toString() {
		String s = super.toString();
		s += " at one time the dogs can give brith more than " + breed + " pups";
		return s;
	}

	@Override
	public void printVetAppointmentReminder() {

		System.out.println("Hey, yours dog has appontment for vaccination.");
	}
	{
	
}
	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Dog) {

			Dog otherDg = (Dog) obj;

			boolean petPartsEqual = super.equals(otherDg);

			boolean sameBreed = this.breed.equals(otherDg.breed);

			return petPartsEqual && sameBreed;
		} else {
			return false;
		}
	}

	@Override
	public int compareTo(Pet o) {
		// TODO Auto-generated method stub
		return 0;
	}
 
}
