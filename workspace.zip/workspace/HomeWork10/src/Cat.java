
public   class  Cat extends Pet {
	// name,age are inherited from pet
	private boolean indoorCat;
	
	public Cat(String name, int age, boolean indoorCat) {
		super(name,age);
		this.indoorCat=indoorCat;
	}
	// getters and setters for name, age are inherited
	public boolean getIndoorCat() {
		return indoorCat;
	}
	public void setIndoorCat(boolean indoorCat) {
	
		if(indoorCat==true){
		
		 this.indoorCat = indoorCat;
	 }
	 else {
		 System.out.println("The cat is lives out of the  house , neans like home less.");
	 }
	}
	 
	
	@Override
	public String toString() {
		String s=super.toString();
		s += indoorCat;
		return  s;
	}
	@Override
	public  void printVetAppointmentReminder(){
		System.out.println(" Please come 15 minute before your appointment.");
	
	}
	@Override
	public int compareTo(Pet o) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
