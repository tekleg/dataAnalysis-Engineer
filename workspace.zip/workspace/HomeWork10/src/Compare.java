
public interface Compare {

}
