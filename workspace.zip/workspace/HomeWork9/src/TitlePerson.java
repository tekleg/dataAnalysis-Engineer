
public class TitlePerson extends Person {

	// name inherited from person

	private String title;

	// a default constructor that takes no parameters

	public TitlePerson() {
		title = "";

	}
	// a constructor that takes in both the name and title as parameters

	public TitlePerson(String title, String name) {
		super(name);
		this.title = title;
	}

	public void setTitle(String title) {
		this.title = title;

	}

	public String getTitle() {
		return this.title;
	}

	@Override
	public String toString() {
		return "Name: " + title + " " + super.getName();
	}

	@Override
	public boolean equals(Object obj) {
		
		if (obj instanceof TitlePerson) {
			
			TitlePerson otherTitlePerson = (TitlePerson) obj;
		
			boolean sameTitle = this.title.equalsIgnoreCase(otherTitlePerson.title);

			return sameTitle;
		}

		else {
			return false;
		}
	}

}