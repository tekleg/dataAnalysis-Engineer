
public class SchoolTester {
	public static void main(String[] args) {

		// Create an array to hold 5 Person objects
		 School[] arr = new Person[4];

		// Fill the array with some Person and some TitledPerson objects
		arr[0] = new  School("CCSf",45);
		arr[1] =   new School("UCSf",120);
		arr[2] = new  PrivateSchool(" ACSF",250);
		arr[3] =  new  PrivateSchool(" ACSA",260);
		 

		// Iterate the array and print a text representation of each object
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i].toString());
		}

		// Iterate the array and count how many "Dr" titles are in the array
		int counter = 0;
		for (int i = 0; i < arr.length; i++) 
			if (arr[i] instanceof TitlePerson)
				if (((TitlePerson) arr[i]).getTitle().compareToIgnoreCase("Dr.") == 0)
					counter++;

	
		System.out.println("There are " + counter + " doctors.");
	}

}
