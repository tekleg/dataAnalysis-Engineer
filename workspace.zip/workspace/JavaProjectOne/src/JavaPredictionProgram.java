//Masters
//January 2017
//Error Prediction Program

//this is the class header- it defines the class
 
public class JavaPredictionProgram {




    /*
	 * this is a method
	 * this particular method is actually a special one you'll see a lot
	 */
	public static void main( String[] args) {

		// this is a Java statement
		System.out.println("This is a test of the Emergency Broadcast System.");
     System.out.println("This is only a test.");

     
final int TEWENTY=20,TENS = 10, FIVES = 5,ONES = 1;	

int numDollar=54;

int numTewenties, numTens, numFives, numOnes;

numTewenties = numDollar/TEWENTY;

numTens = (numDollar%TEWENTY)/TENS;

numFives = ((numDollar%TEWENTY)%TENS)/FIVES;

numOnes = ((numDollar%TEWENTY)%TENS)%FIVES;

System.out.println("numTewenties =" + numTewenties);

System.out.println("numTens =" + numTens);

System.out.println("numFives =" + numFives);

System.out.println("numOnes =" + numOnes);

 
	} // end of the method

} // end of the class
