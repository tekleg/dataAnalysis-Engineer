
public class RetailItemTester {

	public static void main(String[] args) {
	
		//constructor
	RetailItem coke = new RetailItem("zero coke",1.25, 2.15, 30);
	RetailItem sprite = new RetailItem("sprite", 1.20, 2.20,50);
	
	//getter
	System.out.println(coke.getDescription());
	System.out.println(coke.getBuyingPrice());
	
	//setter
	coke.setNumber(48);
	System.out.println(coke.getDescription());
	System.out.println(coke.getNumber());
	
	//toString
	System.out.println(coke.toString());
	System.out.println(sprite.toString());
	
	//other method
	coke.profit();
	sprite.profit();
	 
	}

}
