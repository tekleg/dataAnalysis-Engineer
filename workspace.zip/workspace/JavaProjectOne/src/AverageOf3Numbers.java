import java.util.Scanner;
public class AverageOf3Numbers {
	public static void main(String[] args) {   
		//Create variables numb1, numb2 & numb3
		double numb1, numb2, numb3;
		System.out.println("Enter two numbers you'd like to be averaged.");
		//Read standard input (keyboard)
		Scanner keyboard = new Scanner(System.in);
		//Retrieve first input as an int
		numb1 = keyboard.nextInt();
		//Retrieve second input as an int
		numb2 = keyboard.nextInt();
		//Declare the average value
		double average;
		//Create an average instance of the class average
		Average averageObject = new Average();
		//Call your average method
		average = averageObject.average(numb1,numb2);
		//Print the result
		System.out.println("Average is : " + average);
		}
}