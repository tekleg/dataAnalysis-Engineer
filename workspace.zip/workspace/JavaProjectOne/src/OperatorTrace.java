
public class OperatorTrace {

	public static void main(String[] args) {
		// Operator Trace in java in mixed type.
		System.out.println("The values of the expressions are:");
		int a=2, b=3, c=5, d=6;
        int e;
		double x = 3.0, y = 4.0;
		 double k,z,w;
       
       
      e= ( (d / c) + (c - d) ) * (a + b);
      
      
      k=(c / b) + (c / y);

      z=(x + y) / (c / d);

      w=(y / x) + (b / a);
		
      
		
		System.out.println("( (d / c) + (c - d) ) * (a + b)="+e);
		System.out.println(" (c / b) + (c / y)=)" + k);
		System.out.println("(x + y) / (c / d)="+ z);
		System.out.println("(y / x) + (b / a)="+ w);
		 
		}

}
