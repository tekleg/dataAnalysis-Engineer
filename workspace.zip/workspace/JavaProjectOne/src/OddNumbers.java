
public class OddNumbers {

	public static void main(String[] args) {
	
	/*	int[]oddNum=new int[100];
		
		for(int i=0; i<oddNum.length; i++){
			int oddnumbers;
			oddNum[i]= (i*2)+1;
			//oddnumbers=oddNum[i];
		
		System.out.println( oddNum[i]);
		
		*/
		int[]primeNum=new int[100];
		for(int j=0; j<primeNum.length; j++){
		if	( primeNum[j]%5==0){
			primeNum[j]=primeNum[j]*5;
					
			//oddNum=primeNum;
			 
			 
		}
		 
		System.out.println(primeNum [j]);	
		 
		}
			
		}

	}


