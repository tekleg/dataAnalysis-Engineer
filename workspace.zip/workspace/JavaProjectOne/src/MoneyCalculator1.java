import java.util.Scanner;

        public class MoneyCalculator1 {

	    public static void main(String[] args) {
		 
		final double QUARTER_IN_A_DOLLAR=0.25;
		final double DEMIS_IN_A_DOLLAR=0.10;
		final double NICKLE_IN_A_DOLLAR=0.05;
		final double PENNy_IN_A_DOLLAR=0.01;
		 
			   Scanner scan = new Scanner (System.in);
		        
		       System.out.println("Enter the number of quarters:");
		       int numQuarters = scan.nextInt();
		         
		        
		       System.out.println("Enter the number of dimes:");
		        int numDimes = scan.nextInt();
		       
		       System.out.printf("Enter the number of nickles:");
		        int numNickles= scan.nextInt();
		       
		        System.out.println("Enter the number of pennies:");
		        int numPennies= scan.nextInt();
		        
		        
		       double totalMoney=numQuarters*QUARTER_IN_A_DOLLAR;
		       totalMoney+=  numDimes*DEMIS_IN_A_DOLLAR;
		       totalMoney +=  numNickles*NICKLE_IN_A_DOLLAR;
		       totalMoney +=  numPennies*PENNy_IN_A_DOLLAR;
		       
		       System.out.println( "TotalMoney =" + totalMoney+ " Dollar" );        
		         
	}

}
