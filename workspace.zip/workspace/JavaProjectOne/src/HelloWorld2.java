 
	import java.util.Scanner;
	public class TimeCalculator 
	{
	    public static void main(String[] args)
	    {
	        Scanner input = new Scanner (System.in);
	    
	        int hours;
	        int minutes;
	        int seconds;
	        
	        System.out.printf("Enter the number of hours: ");
	        hours = input.nextInt();
	        System.out.printf("Enter the number of minutes: ");
	        minutes = input.nextInt();
	        System.out.printf("Enter the number of seconds: ");
	        seconds = input.nextInt();
	        
	        
	        System.out.printf( "nTotal seconds is %dn",(hours / 3600) + (minutes / 60) + (seconds));
	        
	        if (hours < 0)
	            System.out.printf( "Invalid");


	    }}