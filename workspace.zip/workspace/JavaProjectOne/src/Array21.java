/*Write code to accomplish the following:

read in Strings from the user; the user enters "quit" to stop 
store the Strings in an ArrayList ("quit" is not stored in the list)
iterate through the ArrayList and print each String to the console
iterate through the ArrayList and count how many Strings are equal to "HELLO" (case sensitive)
*/

/*import java .util.*;
import java.util.Arrays;

public class Array21 {

	public static void main(String[] args) {
		 
		ArrayList<String> wordList = new ArrayList<String>();
		 
		Scanner scan = new Scanner(System.in);
		boolean keepReading = true;
         while( keepReading ){
        	 System.out.println("Enter the word");
		//System.out.println("quit");
			String userword = scan.nextLine();
			if(userword.equalsIgnoreCase("quit")){
		      keepReading = false; 
			}
			else{
				wordList.add(userword);
				}
			}
         System.out.println(wordList);
			 
		
		     int count= 0;
			 for(int i=0; i<wordList.size(); i++){
				if(wordList.get(i).equals("HELLO")){
					count++;
				}
			 }
			 System.out.println("The user enterd  " + count + " HELLO");
		}
	}
*/

