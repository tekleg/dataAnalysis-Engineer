
public class Array23 {

	public static void main(String[] args) {
		 int[] num1 = { 1, 2, 3};
	        int[] num2 = { 6, 7, 8 };
	         
	        switchThem(num1,num2);
	        System.out.println();
	        for (int number : num1) {
	            System.out.print(number + "\t");
	        }
	        System.out.println();
	        
	        for (int number : num2) {
	            System.out.print(number + "");
	        }
	        System.out.println();
	        
	
	}
 public static void switchThem (int[] array1, int[] array2) {
	        int[] temp = array1;
	        if(array1.length==array2.length){
	        array1 = array2;
	        array2 = temp;
	        for (int number : array1) {
	            System.out.print(number + "\t");
	        }
	        }else{
	        	System.out.print("error");}
	        System.out.println();
	        if(array1.length==array2.length){
	        	 array2 = temp;
	        
	       for (int number : array2) {
	            System.out.print(number + "\t");
	            }
	       }
	        else{
	        	System.out.print("error");
	        	}
	    }
 }
/*public static void switchThem (int[] array1, int[] array2) {
 if(first.length==second.length){
 System.out.print("First: " +Arrays.toString);
 */