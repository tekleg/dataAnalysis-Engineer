        
        public class MoneyConversion {
        public static void main(String[] args) { 
		
       final double QUARTER_IN_A_DOLLAR=0.25;
		
		final double DEMIS_IN_A_DOLLAR=0.10;
		final double NICKLE_IN_A_DOLLAR=0.05;
		final double PENNIES_IN_A_DOLLAR=0.01;
	 
		 
		int numQuarters, numDimes, numNickels, numPennies; // entered by the user
		
		double totalValue; 
	
		 
		numQuarters = 3;
		numDimes = 4;
		numNickels = 2;
		numPennies = 7;
	        
	         
	        
	       
	        
	        
	        
		 totalValue = numQuarters*QUARTER_IN_A_DOLLAR;
		 totalValue +=  numDimes*DEMIS_IN_A_DOLLAR;
		 totalValue +=   numNickels* NICKLE_IN_A_DOLLAR;
		 totalValue +=  numPennies* PENNIES_IN_A_DOLLAR;
	       
	       
	System.out.println( " TotalValue  =" +  totalValue + " Dollar" );        
	         


		}

	}

	


