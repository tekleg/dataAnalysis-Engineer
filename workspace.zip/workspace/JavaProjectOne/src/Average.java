import java.util.Scanner;
public class Average {

	
public  void printAverage(int num1, int num2, int num3) {	
	
	double avg =((double)(num1+num2+num3)/3);
 	System.out.println("Average is:" +avg);
}
public static void main(String [] args){
			 
int num1,  num2,  num3;  //Create variables numb1, numb2 & numb3

Scanner scan = new Scanner(System.in); //Read standard input (keyboard)
				
System.out.println("Enter three numbers you'd like to be averaged..");
num1 = scan.nextInt(); //Retrieve first input as an int.
				
num2 = scan.nextInt(); //Retrieve second input as an int
				   
num3 = scan.nextInt(); //Retrieve third input as an int
Average obj=new Average();
obj.printAverage( num1, num2,  num3);
			 
}
 }
	

