import java.util.Scanner;
public class VowelsAndNonvowels {

public static void main(String[] args) {
/*	System.out.println("let's count vowels");

Scanner scan = new Scanner(System.in);	 

System.out.println("let's count vowels");
*/ 

/*
 * for (int i=1; i<=100; i++){
	System.out.println("the factorial number" + i ); //check all the possible valuve from 1 to i
	for(int j=1; j<=i;j++){
		if (i%j==0){
		System.out.println(j+ "");
			}//eng of the if
		}//end of the inner
	System.out.println();

} //end of the outer */
}
}