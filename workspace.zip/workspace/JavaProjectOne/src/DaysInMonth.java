import java.util.Scanner;
public class DaysInMonth {

	public static void main(String[] args) {
Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the month number:");
		int monthNum = Integer.parseInt(scan.nextLine());

		switch(monthNum) {
			case 1:			case 3:			case 5:
			case 7:			case 8:			case 10:
			case 12:
				System.out.println("There are 31 days in that month.");
				break;
			case 2:
				System.out.println("There are 28 days in that month.");
				break;
			case 4:			case 6:			case 9:
			case 11:
				System.out.println("There are 30 days in that month.");
				break;
			default:
				System.out.println("Invalid month number.");
				break;
		}

	}

}
