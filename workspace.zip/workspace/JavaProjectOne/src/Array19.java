/*Write a method that takes an int array originalArray as a parameter.

The method returns an int array that contains the contents of originalArray in reverse order.
The elements of originalArray should remain the same when the method completes.
The method header is: public int[] createReverseArray(int[] originalArray)
Note: If you want to test this method by invoking it from main, you will need to add "static" to the method header (public static int[]...)
*/
import java.util.Arrays;
public class Array19 {

	public static void main(String[] args) {
	 
	int[] num={2,5,7,9,8,12};
	
	
	for(int i=0; i<  num.length; i++){
	
	 
	}
	System.out.println( Arrays.toString( num));
	
	System.out.println(Arrays.toString (createReverseArray(num)));
}

	public static int[] createReverseArray(int[]  originalArray)	{
		
		int[]numbers= new int [originalArray.length];
		 
		 
	for(int j= originalArray.length-1, i=0 ; j>=0 & i<  originalArray.length; j--, i++){
			 
		numbers[j]=  originalArray[i];
		}	
		
	   return  numbers  ;
	}
	
}