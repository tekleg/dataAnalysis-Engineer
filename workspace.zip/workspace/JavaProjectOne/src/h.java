/* 16. Write code to do the following actions 50 times. Use a loop.

generate a random number that is either 0 or 1
output "Yes" for 1 and "No" for 0

       */
import java.util.Random;
      
        public class h {
	    public static void main(String[] args){
	    	Random generator = new Random();
	         
	         int num=0;
	         
	         for (int i = 0; i< 50; i++) {
	         
	         num = generator.nextInt(2);
	          
	         if(num == 1) {
	         
	          System.out.println("yes");
	          }
	          else{
	          System.out.println("No");
	         }
	         	
	        }
	      }

	    
        }
      
        /* 17.  Write code that reads in a negative number from the user. Use a loop to ensure proper input.

        Ask the user to enter a number.
        If the number is negative, print it.
        If the number is not negative, repeat (read in another number). 
	    	
           
           
           import java.util.Scanner;
	    	NegativeNumber{
	    	public static void mail (String[] args)   { 

	    	Scanner scan= new Scanner (System.in); 
	    	System.out.println("Enter a number: ");
	    	int num = scan.nextInt();
	    		
	    	while (num>0) {
	    	System.out.println("Enter a number again: ");
	    	num=scan.nextInt();
	    	}
	    	System.out.println("the number is " + num);
	    			

	    	}
	    	}	
        	*/
      
        
        /* 18. Write code that will read in ten names from the user
        and echo a greeting (such as "Hello Jess") in response to each name. 
        Use a loop. This code would go 
        
        
        inside the main method.
        import java.util.Scanner;

        public class EchoGreeting {

        public static void main(String[] args){
          
         Scanner scan=new Scanner(System.in);
     	    	
         for(int i =0; i<10; i++); {
      
         System.out.println("Enter your name: ");
      	
         String name=scan.nextLine();

         System.out.println("hi" +name);
      

       }
      }
     }
        */
	  
	    	
/* 19. Write nested loops to output this pattern:      
 Hint: have your loops count down. Use the index of the outer loop to 
define your inner loop. Think about using both System.out.print and System.out.println.
	    		
 for(int i=0; i<7; i++)  {

            for(int j=i; j<7; j++) {
        			  
            System.out.print("*");
         }
             System.out.println();
        }
	    */