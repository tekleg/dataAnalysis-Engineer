import java.util.*;
public class UsernameGenerator {

	public static void main(String[] args) {
Scanner scan = new Scanner(System.in);
		
		System.out.println("Welcome to the Username Generator!");
		
		System.out.println("Enter your first name:");
		String firstName = scan.nextLine();
		
		System.out.println("Enter your last name:");
		String lastName = scan.nextLine();
		
		System.out.println(generateUsername(firstName, lastName));
		
		
		int x=5;
		switch (x) {
		case 3 : x += 1;
		case 4 : x += 2;
		case 5 : x += 3;
		case 6 : x++;
	 
		case 7 : x += 2;
		System.out.print(x);
		case 8 : x--;
		case 9 : x++;
		
		}
	}
	public static String generateUsername(String firstName, String lastName) {
		//firstName.charAt(0); // returns a char
		
		String username = firstName.substring(0,1); // returns a String
		
		if(lastName.length() >= 5) {
			username = username + lastName.substring(0,5);
			// username += lastName.substring(0,5); // another way to write the above line
		} else {
			username += lastName;
		}
		
		Random generator = new Random();
		int randomNumber = generator.nextInt(90) + 10;
		
		username += randomNumber;
		// same as: username = username + randomNumber;
		
		username = username.toLowerCase();
		
		return username;
	}}

	
 