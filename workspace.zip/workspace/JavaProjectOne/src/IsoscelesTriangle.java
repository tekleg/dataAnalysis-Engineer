import java.util.Scanner;
public class IsoscelesTriangle {

	public static void main(String[] args) {
System.out.println("Welcome to the Isosceles Triangle program!");

Scanner sc=new Scanner (System.in);
 
System.out.println("Enter the first side of the triangle:");
int s1=sc.nextInt();

System.out.println("Enter the second side of the triangle:");
int s2=sc.nextInt();

System.out.println("Enter the third side of the triangle:");

int s3=sc.nextInt();
System.out.println( triangle(s1,s2,s3));  

} //end of the main method end
 
 
 
public static boolean triangle (int s1, int s2, int s3) { //start boolean method 
  
	 
	if (s1>=s2+s3 || s2>=s3+s1 || s3>=s2+s1) {    /*one side of a triangle can't be equal
		                                        or greater than the sum of the other two sides. */
		return	false;
	}	
		
	if(s1==s2 && s2==s3) { 
	
		return false;	
		
	}
	
	if (s1==s2 || s1==s3 || s2==s3) {
		
		return true;
		
	}
	
	else{	 
		
		return false;
    	
    }
 

 } //end of the boolean method
} //end of the class