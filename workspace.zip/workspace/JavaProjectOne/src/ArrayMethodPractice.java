import java.util.*;
public class   ArrayMethodPractice {                                //Practice
                                                                    //1. Fill an array with 100 random integers
	public static void main(String[] args) {                        //   between 0 and 499. Then write a method to:
		int[] numbers = new int[100];                               //2. find the maximum value in the array.
	// 1.	                                                //3. print the elements in the array in reverse order.(Do not change the array.)
		Random generator = new Random();                //4.  print all elements in the array that are greater than a passed parameter. 
		for(int i=0; i<numbers.length; i++) {           //5.  return the sum of all elements greater than a passed parameter.
			numbers[i] = generator.nextInt(500);        //6. return the number of even elements in the array.
		}                                               //7. zero out array
		
		System.out.println(Arrays.toString(numbers));
		
		//2.
		
		System.out.println("The max is " + findMax(numbers));
		
		//3.
		printReverse(numbers);
		
		//4.
		printGreaterThan(numbers, 450);
		//5.
		int sum = sumGreaterThan(numbers, 450);
		System.out.println("The sum is " + sum);
		
		//6.
		System.out.println("The array contains " + countEvens(numbers) +
				" even numbers");
		//7.
		zeroOutArray(numbers);
		System.out.println(Arrays.toString(numbers));

	}
	
	public static void zeroOutArray(int[] values) {  //7
		//values = new int[100];
		for(int i=0; i<values.length; i++) {
			values[i] = 0;
		}
	}
	
	public static int countEvens(int[] nums) {   //6
		int evens = 0;
		for(int num : nums) {
			if(num%2==0) {
				evens++;
			}
		}
		return evens;
	}
	
	public static int sumGreaterThan(int[] nums, int value) {  //5
		int sum = 0;
		for(int num : nums) {
			if(num > value) {
				sum += num; // equivalent to sum = sum + num;
			}
		}
		return sum;
	}
	
	public static void printGreaterThan(int[] nums, int value) {   //4
		for(int num : nums) {
			if(num > value) {
				System.out.println(num);
			}
		}
	}
	
	public static void printReverse(int[] nums) {   //3
		for(int i=nums.length-1; i>=0; i--) {
			System.out.print(nums[i] + ", ");
		}
		System.out.println();
	}
	
	public static int findMax(int[] numbers) {   //2
		int max = numbers[0];
		for(int num : numbers) {
			if(num > max) {
				max = num;				
			}
		}
		// for(int i=0; i<numbers.length; i++) {
			// if(numbers[i] > max)
		
		return max;
	 
	}

}


