
public class  RetailItem{

//instant data variable//////////
private String description;
private double buyingPrice;
private double sellingPrice;
private int number;
		 
//constructor//////	

public RetailItem(String describedItem,double buyingItem, double sellingItem, int num){
description = describedItem;
buyingPrice = buyingItem;
sellingPrice = sellingItem;
number = num;

}
//getters//////////
public String getDescription(){
return description;
}

public double getBuyingPrice(){
return buyingPrice;
}
public double getSellingPrice(){
return sellingPrice;
}

public int getNumber(){
return number;
}

//setters////////

public void setDescription(String newDescription){
description = newDescription;
System.out.println("The description of the item has changed now to " + description);

}

public void setBuyingPrice(double newBuyingPrice){
buyingPrice = newBuyingPrice;	
if(newBuyingPrice >= 0){
buyingPrice = newBuyingPrice;
}
else{
System.out.println("The buying price of the item should not be negative.");
}
}

public void setSellingPrice(double newSellingPrice){
if(newSellingPrice < 0){
System.out.println("The selling price of the item should not be negative.");

}
else{
sellingPrice = newSellingPrice;
}
}
public void setNumber(int newNumber){
if(newNumber >=0){
number = newNumber;
}
else{
System.out.println("The number of the item should not be negative.");
}
}

//toString method////////
public String toString(){
return "The number of the item are:" + number +
		"\n\tThe buying price of the items:" + buyingPrice +" "+ "for each" +
		"\n\tThe selling price of the item is:" + sellingPrice +" "+ "for each";
}		 
 //other method///
public void profit (){
if( (sellingPrice*number) > (buyingPrice*number)){
System.out.println("He is profitable");	
}
else{
System.out.println("He is better to quit the business");
}
}
}

