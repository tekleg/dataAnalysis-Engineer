import java.util.Scanner;
public class RaffleGameWinners {

	public static void main(String[] args) {
/*System.out.println("Welcome to the Raffle Game:");
Scanner sc=new Scanner (System.in);
System.out.println("Enter the smallest number:");
*/
		 
		
		
	}

}
