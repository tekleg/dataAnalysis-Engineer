/*
 Write a method to determine how many numbers in one array are in another.

The method is passed an array that holds the winning lottery numbers and an array that holds some person's lottery ticket numbers. The method figures out how many winning numbers the person has on their ticket.

the method header is: public int countWinningNumbersOnTicket(int[] winningNumbers, int[] lotteryTicket) 
Note: If you want to test this method by invoking it from main, you will need to add "static" to the method header (public static double...)
you can assume the arrays have the same length
the arrays are not sorted
there are no duplicate numbers in either array
examples:
winning numbers [61, 51, 91, 3, 24], lotteryTicket [24, 14, 61, 52, 92] return 2 (because the lottery ticket has two winning numbers- 24 and 61)
winning numbers [61, 51, 91, 3, 24], lotteryTicket [34, 14, 68, 52, 92] return 0 (because the lottery ticket has no winning numbers)
winning numbers [61, 51, 91, 3, 24], lotteryTicket [24, 3, 61, 91, 51] returns 5 (because the lottery ticket has tall five numbers- they hit the jackpot!)

 
 */
 
import java.util.*;

public class Array22 {

	public static void main(String[] args) {
	int[] nums =  {61, 51, 91, 3, 24};	 
	int[] nums2 = {61, 57, 51, 77, 65};	 
	
	System.out.println(countWinningNumbersOnTicket(nums, nums2));
	
	}
	
	public static int countWinningNumbersOnTicket(int[] winningNumbers, int[] lotteryTicket) {
	int count = 0;
		for(int i=0;i<winningNumbers.length; i++)	{
		
		for(int j=0;j<lotteryTicket.length; j++)	{
	if(winningNumbers[i]==lotteryTicket[j]) {
		count++;
		
	}
	
	}
		
		
	}
		return count;
	}
}
