 
public class Dog {
	
	//istance data variable
private int age; 
private int name; 
private int weight; 
private int vaccinated;  

  //constructor
public Dog( String intialName,int intialAge, double intialWeight , boolean intialVaccination) {
 
	name = intialName;
	age = intialAge;
	weight= intialWeight;
	
}

}


