
public class Arrar18 {
	public static void main (String[]args){
	
	String[] array= {"apple","pear", "banana", "peach", "tomato"};
	
	for(int i=0; i<array.length; i++){
		
		System.out.print(array[i]+ ",");
		
	}
	
	System.out.println( );
	for(int i=0; i<array.length; i++){
		
	 array[i]= array[i].toUpperCase();
	
	 System.out.print(array[i]+ ",");
	}
	String[]array2=new String[10];
	
	for(int i=0; i<array.length; i++){
		
	array2[i]=array[i];
	
	}
	array2[5]= "orange";
	array2[6]= "egg";
	
	array2[7]= "Strowberry";
	array2[8]= "potato";		
	array2[9]= "qwi";		
	
	System.out.println( );

	
	for(int i=0; i<array2.length; i++){
	
		System.out.print(array2[i] + ", ");
	
	}

	}
}