import java.util.*;
public class Array17 {

	public static void main(String[] args) {
		 
		int[]numbers=new int[20];
		  
		 
		
		for (int i=0; i<numbers.length; i++){
			
			Random generator=new Random();
			int n = generator.nextInt(10) +1;
			numbers[i]=n;
			System.out.print(numbers[i] + ", ");
		}
		    System.out.println(" ");
		for (int i=0; i<numbers.length; i++){  
		
			if (numbers[i]%2==0){
				numbers[i]*=2;
			}
		}
		for (int i=0; i<numbers.length; i++){  
	
			System.out.print(numbers[i] + ", ");
			
		 }

	}


}