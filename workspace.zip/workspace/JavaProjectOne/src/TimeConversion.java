import java.util.Scanner;
public class TimeConversion {

	public static void main(String[] args) { 
	final int NUM_SECONDS_IN_AN_HOUR=3600;
	final int NUM_SECONDS_IN_A_MINUTE=60;
		System.out.println("Welcome to the Time Convertion Program the number: ");
		Scanner scan = new Scanner (System.in);
        
        System.out.println("Enter the number of hours:");
        String hoursString = scan.nextLine();
        int numHours= Integer.parseInt(hoursString);
        
        System.out.printf("Enter the number of minutes:");
        String minutesString = scan.nextLine();
        int numMinutes= Integer.parseInt(minutesString);
       
        System.out.printf("Enter the number of seconds:");
        String secondsString = scan.nextLine();
        int numSeconds= Integer.parseInt(secondsString);
       int totalSeconds=numHours*NUM_SECONDS_IN_AN_HOUR;
       totalSeconds +=  numMinutes*NUM_SECONDS_IN_A_MINUTE;
       totalSeconds += numSeconds;
       
        System.out.println( "That is" + totalSeconds + " seconds" );        
         


	}

}
