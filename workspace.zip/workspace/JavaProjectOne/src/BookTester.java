
public class BookTester {

public static void main(String[] args) {
Book b1 = new Book("book1", "John", "city college", 2017); 
Book b2 = new Book("book2", "Angel", "Harvard", 2013); 

System.out.println(b1.getTitle());

b1.setAuther("David");
b2.setCopyrightYear(-9);
System.out.println(b2.getCopyrightYear());

System.out.println("Book1: " + b1.toString());
System.out.println("Book2: " + b2.toString());

	}

}
