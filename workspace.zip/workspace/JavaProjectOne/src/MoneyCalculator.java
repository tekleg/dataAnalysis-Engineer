
public class MoneyCalculator {

}
