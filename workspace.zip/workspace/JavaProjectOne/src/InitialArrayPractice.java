
public class InitialArrayPractice {                  //• Write code to declare and initialize:
//An array that will store the first 4 prim          // 1. An array that will store the first 4 prime numbers
                                                     // 2. An array that will store three names
public final static char FAILING_GRADE = 'F';        // 3.An array that will store the possible
	                                                 //  letter grades A, B, C, D, and F
	public static void main(String[] args) {
		int[] primeNumbers;
		primeNumbers = new int[4];  // indices go from 0 to 3
		
		System.out.println("the prime number array can hold " + primeNumbers.length
				+ " elements");
		//primeNumbers.length = 10; // not allowed
		primeNumbers[0] = 2;
		primeNumbers[1] = 3;
		primeNumbers[2] = 5;
		primeNumbers[3] = 7;
		// primeNumbers[4] = 11; // will crash at runtime
		System.out.println("The first prime is " + primeNumbers[0]);
		System.out.println("The last prime in our list " + primeNumbers[primeNumbers.length-1]);
		int result = primeNumbers[2] * 4 % 3; // primeNumbers[2] is an int- that's its type
	
	
		
		
		/*=======================================================================
		 2. An array that will store three names
		*/
		
		
		/* option 1: declare and initialize in one line; then fill each space on its own */
		/*
		String[] names = new String[3];
		// indices go from 0 to 2
		names[0] = "Jessica";
		names[1] = "Jennifer";
		names[2] = "Jeffery";
		*/
		
		
		/* option 2: use initializer list */
		
		String[] names = {"Jessica", "Jennifer", "Jeffery"};
		
		System.out.println("The first name is " + names[0].toUpperCase());
		// names[0] is a String- that's its type
		
		
		
		//=======================================================================
		                                   /* 3.An array that will store the possible
                                            letter grades A, B, C, D, and F	  
		                                    */
		 
		 /*
		char[] grades = new char[5];
		// indices go from 0 to 4
		grades[0] = 'A';
		grades[1] = 'B';
		grades[2] = 'C';
		grades[3] = 'D';
		grades[4] = 'F';
		*/
		char[] grades = {'A', 'B', 'C', 'D', FAILING_GRADE};
		method(grades[2]); // grades[2] is a char- that's its type
		System.out.println("["+grades[0]+"]");
		
		AudioItem[] catalog = {                  // catalog is an object the type of catalog is an AudioItem array
				
				new AudioItem("title1", 0.99, 180),
				new AudioItem("title2", 1.99, 250)
			};

		System.out.println(catalog[0].getNumSeconds());
	
		
		
		//===================================================================================
		int[] nums = new int[100];
		
		// fill up the array with values
		for(int i=0; i<nums.length; i++) {
			nums[i] = i * 5;
		}
		
		// retrieve elements from array
		for(int i=0; i<nums.length; i++) {
			System.out.println(nums[i]);
		}
		
		// modify elements: double all elements at an even index
		for(int i=0; i<nums.length; i++) {
			if(i%2==0) { // index is even
				nums[i] = nums[i] * 2;
			}
		}
		
		System.out.println(nums);
		
		
		
		
		
		

	}

	public static void method(char c) {
		// does something
	}
	
}


	}

}
