
   public class HelloWorld {

	public static void main(String[] args) {
		
		System.out.println("Java Modulus Operator examples:");
        
        //Modulus operator returns reminder of the devision of integer types.	
		int x=1, y=2;
		if(x > 0) {

			if(y>1)

			System.out.println(y );

			y *= -1;

			} else {

			if(y<1)

			System.out.println(x);

			y *= -2;

			}

			x -= 1;

			if(x >=1) {

			if(y!=0)

			System.out.println(y );

			} else if(x <=-1) {

			if(y==0) {

			System.out.println(y );

			} else if(x==0) {

			System.out.println(x);

			}

			} else {

			System.out.println(x);

			}

			System.out.println(x + "" + y);
		
		
	
	}

}