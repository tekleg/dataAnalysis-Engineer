
public class Book {  
private String title;   
private String auther;
private String publisher;
private int copyrightYear;

//constructor///////
public Book(String intialTitle, String intialAuther, String intialPublisher, int intialCopyrightYear) {

	title = intialTitle;
	auther = intialAuther;
	publisher = intialPublisher;
	copyrightYear = intialCopyrightYear;
	}


//getters////////////////

public String getTitle(){
return title;
}
public String getAuther(){
return auther;
} 
public String getPublisher(){
return publisher;	
}

public int getCopyrightYear(){
return copyrightYear;
}

//setters/////////
public void setTitle(String newTitle){
title = newTitle;
}
public void setAuther(String newAuther){
auther = newAuther;
}

public void setPublisher(String newPublisher){
publisher = newPublisher;
}
public void setCopyrightYear(int newCopyrightYear){
	if(newCopyrightYear >= 0) {
		copyrightYear = newCopyrightYear;
	} else {
		System.out.println("Year cannot be negative.");
	}
}
public String toString(){
return "Title:" + title +
		"\n\tAuther:" + auther +
		"\n\tPublisher:" + publisher +
		"\n\tCopyright year:" + copyrightYear;
}
}

/*/*boolean quit = false;
String toQuit;
System.out.println("Welcome to the Bank of America.");


System.out.println( "Please enter your account id:");
String id =scan.nextLine();

System.out.println( "Please enter your initial balance.");

double balance = scan.nextInt();





while(!quit) {




bankAcc.getname();
System.out.println(bankAcc.getname() );

//System.out.println("Enter 'Q' to quit. ");
		

toQuit = scan.nextLine();

if(toQuit.equalsIgnoreCase("q")){
	
	quit=true;
	System.out.println("Good bye");

}
*//*boolean quit = false;
String toQuit;
System.out.println("Welcome to the Bank of America.");


System.out.println( "Please enter your account id:");
String id =scan.nextLine();

System.out.println( "Please enter your initial balance.");

double balance = scan.nextInt();





while(!quit) {




bankAcc.getname();
System.out.println(bankAcc.getname() );

//System.out.println("Enter 'Q' to quit. ");
		

toQuit = scan.nextLine();

if(toQuit.equalsIgnoreCase("q")){
	
	quit=true;
	System.out.println("Good bye");

}
public double monthlyMortgageFee(double fee){
		
		if(balance>fee){
		
		balance= balance-fee;
	}
	else{
		  System.out.println("");	
		}
		return fee;
	}
*/