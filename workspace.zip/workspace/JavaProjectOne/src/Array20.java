/*Write a method to compute the average of the elements of an int array and return the value as a double.


 The method header is: public double calculateAverage(int[] nums, int numElements)
The int array and the number of elements in the array are both passed as parameters to the method. 
Note: If you want to test this method by invoking it from main, you will need to add "static" to the method header (public static double...)
Assume that:

numElements is the correct number of elements in the array
numElements is > 0
numElements could be less than the size of the array (meaning some array positions might not hold values to be included in the average)
array elements are filled sequentially starting at position 0
 */
 
public class Array20 {

	public static void main(String[] args) {
	int[] nums= {5,6,7,8,9};	 
		
	System.out.println(calculateAverage(nums, nums.length));

	}
	 public static  double calculateAverage(int[] nums, int numElements){
		 numElements = nums.length;
		 int sum=0;
		 for(int i=0; i<numElements; i++){
			 
			 sum+=nums[i];
			 
		 }
		 double average =  sum/numElements;
		 return average;
	 }

}




