 /*
  * @ Name: Tekle Gebrezgabhier
  * Lab 2. Design and Implement an ADT for a polynomial. 
  * @  compiler Eclipse - Compiler for Java (ECJ) 
  * @ Operating system: Mac OSX  
*/
 //The Exception Class InvalidPowerException :

public class InvalidPowerException extends RuntimeException {
    public InvalidPowerException(String exception){
        super(exception);
    }
}