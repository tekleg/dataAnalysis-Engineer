/*Tekle Gebrezgabhier
 * Assignment : linkedReferenceBaseed
 * compiler Eclipse - Compiler for Java (ECJ) 
 * operating system - OS MAC
 */
 public class ListIndexOutOfBoundsException extends RuntimeException
{
    //-----------------------------------------------------------------
   //  Exception Handler to ask user to re-enter non negative power
   //-----------------------------------------------------------------
    public ListIndexOutOfBoundsException(String exception)
    {
        super(exception);
    }
}