package lab4;

/*Tekle Gebrezgabhier
* Lab4 : main class of Implementation of LinkedQueue 
* compiler Eclipse - Compiler for Java (ECJ) 
* operating system - OS MAC
*/
import java.util.Scanner;

//class is a blueprint of an object
public class myMain {

	// used to print the list in reveres order
	public static void queueList(QueueInterface queue) {
		System.out.print("Reverse Queue Order: ");
		for (int i = 0; i < queue.size(); i++) {
		System.out.print(queue.get(i) + " ");
		} // end for
		System.out.println();
	}// end queueList

	// print the dialog below after every time the
	// conditin has been checked
	public static void doItNow() {
		System.out.println();
		System.out.println("1) Add item:");
		System.out.println("2) Show reverse Queue order:");
		System.out.println("3) Exit Program:");
		System.out.print("\nEnter your choice (1-3): ");
	}// end doItNow

	// main method calls all the other methods required to run.
	public static void main(String[] args) {
		boolean loop = true; // loop controller
		int userInput, userSelc; // var for user input and selection
		Scanner scan = new Scanner(System.in);
		QueueInterface<String> myQueue = new LinkedQueue<String>();
		/////////////////
		// In the do-while loop there are series of if/else-if/else if, which
		// are used to check the conditions
		// The first if is for add an item to the list. The second else
		// if allows the user to reverse the list.
		// The else if is used to exit the program.
		///////////////////
		do {
			doItNow();
			userInput = scan.nextInt();

			if (userInput == 1) { // add item
				System.out.print("Enter item to add: ");
				String userChoice = scan.next();
				System.out.println();
				myQueue.enqueue(userChoice);
			} // end if
			else if (userInput == 2) { // insert the new Node
				myQueue.reverseList();
				queueList(myQueue);
			} // class is a blueprint of an object
			else if (userInput == 3) { // //insert the new Node
				System.out.println();
				loop = false;
				System.out.println("Goodbye");
			} // end else if
		} while (loop); // end do-while loop
	} // end main

} // end myMain
