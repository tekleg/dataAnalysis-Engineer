
/*Tekle Gebrezgabhier
* Lab4 : Implementation of LinkedQueue 
* compiler Eclipse - Compiler for Java (ECJ) 
* operating system - OS MAC
*/

package lab4;

//lastNode references the node at the back of the queue
//lastNode.next references the nose at the front
public class LinkedQueue<T> implements QueueInterface<T> {
	public Node firstNode;
	public Node lastNode;
	
	// definitions of constructors and methods
	public LinkedQueue() {
		firstNode = null;
		lastNode = null;
	}// end default constructor
	
	//queue operations:
	public void enqueue(T newEntry) {
		Node newNode = new Node(newEntry, null);

		  //insert the new Node
		if (isEmpty())
			firstNode = newNode;
		else
			lastNode.setNextNode(newNode);
		lastNode = newNode;
	}// end enqueue

	//return null
	public boolean isEmpty() {
		return (firstNode == null) && (lastNode == null);
	} // isEmpty

	public T dequeue() {
		T front = null;

		if (!isEmpty()) {
			front = firstNode.getData();
			firstNode = firstNode.getNextNode();

			if (firstNode == null)
				lastNode = null;
		}//end if

		return front;
	} // end dequeue

	public T getFront() {
		T front = null;

		if (!isEmpty())
			front = firstNode.getData();
		return front;
	} // getFront

	public void clear() {
		firstNode = null;
		lastNode = null;
	} // end clear
	
	//Adjusts the node references so that the items are in the reverse of 
    //their original order, without creating any new nodes.
	 public void reverseList() {
		Node reversedPart = null;
		Node current = firstNode;
		while (current != null) {
			Node next = current.next;
			current.next = reversedPart;
			reversedPart = current;
			current = next;
		}
		firstNode = reversedPart;
	}
//number of the node references
	public int size() {
		int size = 0;
		Node curr;
		for (curr = firstNode; curr != null; curr = curr.next)
			size++;
		return size;
	} // end size

	private Node find(int index) {

		// Locates a specified node in a linked list.
		// Precondition: index is the number of the desired
		// node. Assumes that 1 <= index <= size()+1
		// Postcondition: Returns a reference to the desired
		// node.

		Node curr = firstNode;
		for (int skip = 0; skip < index; skip++) {
			curr = curr.next;
		} // end for
		return curr;
	} // end find

	public T get(int index) throws ListIndexOutOfBoundsException {
		// int index = ndex - 1;
		if (index >= 0 && index < size()) {
			// get reference to node, then data in node
			Node curr = find(index);
			T dataItem = curr.data;
			return dataItem;
		} else {
			throw new ListIndexOutOfBoundsException("List index out of bounds on get");
		} // end if
	} // end get

	//node class in side in a LinkedQueue class
	public class Node {
		public T data;
		public Node next;

		public Node(T dataPortion) {
			this(dataPortion, null);
		}// end constructor

		//constructor with arguments
		public Node(T dataPortion, Node nextNode) {
			data = dataPortion;
			next = nextNode;
		}// end constructor

		//getter
		public T getData() {
			return data;
		}//end get

		//setter
		public void setData(T newData) {
			data = newData;
		}//end set
		
		//getter
		public Node getNextNode() {
			return next;
		} //end get
		
		//setter
		public void setNextNode(Node nextNode) {
			next = nextNode;
		}//end set

	}//Node

} //LinkedQueue