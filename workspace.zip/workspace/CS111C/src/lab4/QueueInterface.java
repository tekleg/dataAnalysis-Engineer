/*Tekle Gebrezgabhier
* Lab4 : Implemention of LinkedQueue 
* compiler Eclipse - Compiler for Java (ECJ) 
* operating system - OS MAC
*/
package lab4;
// Inteface for the ADT List
public interface QueueInterface<T> {
	public void enqueue(T newEntry);

	public T dequeue();

	public T getFront();

	public boolean isEmpty();

	public void clear();

	public void reverseList();

	public int size();

	public T get(int index) throws ListIndexOutOfBoundsException;
	// end  QueueInterface
}