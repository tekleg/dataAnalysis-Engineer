
/*Tekle Gebrezgabhier
* Lab 4 :   LinkedQueue 
* compiler Eclipse - Compiler for Java (ECJ) 
* operating system - OS MAC
*/
package lab4;

public class ListIndexOutOfBoundsException extends RuntimeException {
	// -----------------------------------------------------------------
	// Exception Handler to ask user to re-enter non negative power
	// -----------------------------------------------------------------
	public ListIndexOutOfBoundsException(String exception) {
		super(exception);
	} // end method
}// end class
