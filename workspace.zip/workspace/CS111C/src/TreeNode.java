
//TreeNode.java
	class TreeNode<Tree> {
	Tree item;
	TreeNode<Tree> leftChild;
	TreeNode<Tree> rightChild;

	public TreeNode(Tree newItem) {
	// Initializes tree node with item and no children.
	item = newItem;
	leftChild = null;
	rightChild = null;
	} // end constructor

	public TreeNode(Tree newItem, TreeNode<Tree> left, TreeNode<Tree> right) {
	  
	item = newItem;
	leftChild = left;
	rightChild = right;
	} // end constructor

	} // end TreeNode




