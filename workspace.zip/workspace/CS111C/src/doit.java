
 import java.util.*;


public class doit 
{
  private static   int[] a = new int[5];
 
  
  
  // EXCEPTION USING SYSTEM EXCEPTION
  public static void main  (String[] args) throws ArrayIndexOutOfBoundsException
  {
    Scanner n = new Scanner(System.in);
    
    // THROWS EXCEPTION AND TERMINATES PROGRAM
    // TRY CATCH - THROWS EXPECTION AND CATCHES IT
    
   // try
     //{
     System.out.print("Enter input: ");
     int inp = n.nextInt();

     if (inp < 0)
       throw new ArrayIndexOutOfBoundsException("Out of Bounds!!!");
     else
     System.out.println("You entered "+ inp);
   /* } 
    catch (ArrayIndexOutOfBoundsException e9) 
     {  
    System.out.println("Array OOB");  
    }  
    */
    System.out.println("END PROGRAM");
  }
  
 
  
     
     
  
  // EXCEPTION USING CLASS 
 /*   public static void main  (String[] args) throws InputException
  {
    Scanner n = new Scanner(System.in);
    
    InputException e = new InputException("No negative values please");
    
    try
    {
     System.out.print("Enter input: ");
     int inp = n.nextInt();

     if (inp < 0)
       throw e;
     else
     System.out.println("You entered "+ inp);
    }
    catch (InputException e1)
    {
     System.out.println("No negative values");    
    }

    System.out.println("END PROGRAM");
  }
  
} */
}