
public class backword {
public static void main(String[] args) {

	int[]arr = {3,5,7,2,9,};	
	ar((arr[j]);
}
static void ar(int arr[]){
	int n=arr.length; 
	 for (int j = arr.length-1; j  >=0; j--) {	
		 System.out.print(arr[j]);
	 }
	}

}
