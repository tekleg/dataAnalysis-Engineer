
public class math115ProgrammingProject {

	public static void main(String[] args) {
		System.out.println("\n\nFirst test case: evenFibonacciSum(40)");
		System.out.println("The Fibonacci sum limitis: 40");
		evenFibonacciSum(40);
		System.out.println("\n\n***********************************\n\nSecond test case: evenFibonacciSum(400)");
		System.out.println("The Fibonacci sum limitis: 400");
		evenFibonacciSum(400);
		System.out.println("\n\n***********************************\n\nThrid test case: evenFibonacciSum(4000)");
		System.out.println("The Fibonacci sum limitis: 4000");
		evenFibonacciSum(4000);

	}

	public static void evenFibonacciSum(int k) {

		int t1 = 0, t2 = 1, sum = 0, esum = 0; // variable declaartion

		System.out.print("Even numbers in Fibonacci series: \n");

		while (sum <= k)  {   // Loop to find fibonacci series
		
			sum = t1 + t2;   // calculate sum
			t1 = t2;
			t2 = sum;
			if (t1 % 2 == 0) { // Find even numbers
				System.out.print(t1 + " ");
				esum += t1;    // Calculate sum
			}
		}

		System.out.print("\nSum of even Fibonacci number is " + esum);
		System.out.println();
	}
}
