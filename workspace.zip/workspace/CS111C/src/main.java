
/*Tekle Gebrezgabhier
 * Assignment : linkedReferenceBaseed
 * compiler Eclipse - Compiler for Java (ECJ) 
 * operating system - OS MAC
 */

import java.util.Scanner;

//class is a blueprint of an object
public class main {

	// check if the items are sorted alphabetically
	public static void checkSorted(ListInterface list) {

		// This condition checks if the listed items are sorted
		if (list.isSorted()) {
			System.out.println("List is in sorted order");
		}
		// This checks if the listed item are not sorted
		else {
			System.out.println("List is not in sorted order");
		}
		System.out.println();
	}

	// used tol print after every time the condition from the if/else-if has
	// been executed.
	public static void doItNow() {

		System.out.println();
		System.out.println("1) Add item \n2) Remove item \n3) Reverse list" + "\n4) Exit Program");
		System.out.println("\n");
		System.out.print("Enter your choice (1-4): ");
	}

	// prints the list.
	public static void printList(ListInterface list) {
		System.out.print("List: ");
		for (int i = 0; i < list.size(); i++) {
			System.out.print(list.get(i) + " ");
		}
		System.out.println();
	}

	// This method prints the number of items on the list.
	public static void printSize(ListInterface list) {
		System.out.println("Number of items: " + list.size());
	}

	// main method calls all the other methods required to run.
	public static void main(String[] args) {
	    
		// The function of the Algorithm in the main method
		// The user will be asked to choose either add item,remove item,
		// reverse list or exit the program by inputting a number & press enter.
		 
		boolean loop = true;
		int input, userSelc;
		Scanner scan = new Scanner(System.in);
		ListInterface mylistedItem = new ListReferencedBased();
		/////////////////
		//In the do-while loop  there are series of if/else-if/else, which  
		//are used to check the conditions
		// The first if is for add an item to the list. The second else
		// if permits the user to remove any item at specified node. 
		//The third  else  if allows the user to reverse the list.
		//The  fourth else-if is used to exit the program.
		///////////////////
		do {
			doItNow();
			input = scan.nextInt();

			if (input == 1) { // add an item to the list.
				System.out.print("Enter position: ");
				userSelc = scan.nextInt();

				if (userSelc == 0 || userSelc > mylistedItem.size() + 1)
					// wrong positioning
					System.out.println("Invalid position: ");
				else // if the user select between (1-4) go head to the list
				{
					System.out.print("Enter item to add: ");
					String choise = scan.next();
					System.out.println();
					mylistedItem.add(userSelc, choise); // added to item to list
					printList(mylistedItem); // prints the listed items
					printSize(mylistedItem); // prints number of items
					checkSorted(mylistedItem); // shows items are sorted on not
				} // end of the else
			
			} // end of the outer if

			else if (input == 2) { // remove an item from the list.
				System.out.print("Enter position: ");
				userSelc = scan.nextInt();
				mylistedItem.remove(userSelc); // removed items item from list
				printList(mylistedItem); // prints the listed items
				printSize(mylistedItem); // prints number of items
				checkSorted(mylistedItem); // shows items are sorted on not
			}

			else if (input == 3) { // reverse the list.
				mylistedItem.reverseList(); // shows how items are reversed
				printList(mylistedItem); // prints the listed items
				printSize(mylistedItem); // prints number of items
				checkSorted(mylistedItem); // shows items are sorted on not
			}

			else if (input == 4) { // exit from the program
				System.out.println();
				loop = false;
				System.out.println("Goodbye");
			}
		} while (loop);
	} // end of the main method
}
