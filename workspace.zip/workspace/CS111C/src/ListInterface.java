/*Tekle Gebrezgabhier
 * Assignment : linkedReferenceBaseed
 * compiler Eclipse - Compiler for Java (ECJ) 
 * operating system - OS MAC
 */
public interface ListInterface {
// ********************************
//  Inteface for the ADT List 
// ********************************

// list operations:
public boolean isEmpty();
public int size();
public void add(int index, Comparable item)
                    throws ListIndexOutOfBoundsException;
public void remove(int index)
                    throws ListIndexOutOfBoundsException;
public Comparable get(int index)
                    throws ListIndexOutOfBoundsException;
public void removeAll();
public boolean isSorted();
public void reverseList();
} // end ListInteface