/**
 * 
 */
/**
 * @author Tekle
 *
 */
package lab5;