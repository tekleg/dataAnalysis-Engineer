package lab5;
 
//StringItem.java

	public class StringItem extends KeyedItem<String> {
		public StringItem(String item) {
			super(item);
		}

		public String toString() {
			return getKey();
		}
	} // end StringItem
