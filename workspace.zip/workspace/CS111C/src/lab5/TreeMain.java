package lab5;

//import java.util.*;
//
//public class TreeMain {
//
//	public static void main(String[] args) {
//		Scanner userScan = new Scanner(System.in); //reads from scanner
//		String userInput;
//		dialog();
//		userInput = userScan.nextLine(); //user input
//		
//	}
//
//	public static void dialog() {
//		System.out.println("Tree sort program");
//		System.out.println("Enter name of input file: ");
//	}
//}
//

//BinaryTreeMonthes.java

/*
public class TreeMain {
	public static void main(String[] args) throws IOException {

		BinarySearchTree<StringItem, String> tree = new BinarySearchTree<StringItem, String>();

		System.out.println("Tree sort program");
		System.out.print("Enter name of input file: ");
		Scanner inputFile = new Scanner(System.in);

		String inputFileName = inputFile.next();
		System.out.println();
		String input = null;

		try {
			// FileReader reads text files in the default encoding.
			FileReader fileReader = new FileReader("src//input.dat");
			BufferedReader bufferedReader = new BufferedReader(fileReader); //BufferReader actually does the reading from a file

			// put into queue.
			while ((input = bufferedReader.readLine()) != null) { //readLine will read a line at a time
				tree.insert(new StringItem(input));	//as it is reading the line,it will display
				//it will keep doing it while the input is not null, which means it will keep doing it until we reach the end of the file.
			}

			bufferedReader.close(); // close .dat
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file '" + inputFileName + "'");
		} catch (IOException ex) {
			System.out.println("Error reading file '" + inputFileName + "'");
		}
		System.out.println("Binary search tree:\n");
		// binary search tree format
		tree.printTree(tree.root, 0);

		System.out.println("Sorted items:");
//		System.out.println('\n' + "Sorted items:" + '\n');
		// display sorted months
		tree.printInorder(tree.root);
	}
}

*/
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
//same as bottom
//same as bottom
import java.util.Scanner;

//import java.io.IOException;
//import java.util.Scanner;
//import java.io.FileReader;
//import java.io.BufferedReader;
//import java.io.FileNotFoundException;

public class TreeMain {
	public static void main(String[] args) throws IOException {

		BinarySearchTree<StringItem, String> tree = new BinarySearchTree<StringItem, String>();

		System.out.println("Tree sort program");
		System.out.print("Enter name of input file: ");
		Scanner inputFile = new Scanner(System.in);

		String inputFileName = inputFile.next();
		System.out.println();
		String input = null;

		try {
			// FileReader reads text files in the default encoding.
			FileReader fileReader = new FileReader(inputFileName);
			BufferedReader bufferedReader = new BufferedReader(fileReader); //BufferReader actually does the reading from a file

			// put into queue.
			while ((input = bufferedReader.readLine()) != null) { //readLine will read a line at a time
				tree.insert(new StringItem(input));	//as it is reading the line,it will display
				//it will keep doing it while the input is not null, which means it will keep doing it until we reach the end of the file.
			}

			bufferedReader.close(); // close .dat
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file '" + inputFileName + "'");
		} catch (IOException ex) {
			System.out.println("Error reading file '" + inputFileName + "'");
		}
		System.out.println("Binary search tree:\n");
		// binary search tree format
		tree.printTree(tree.root);//, 0);

		System.out.println("\nSorted items:");
//		System.out.println('\n' + "Sorted items:" + '\n');
		// display sorted months
		tree.printInorder(tree.root);
	}
}
