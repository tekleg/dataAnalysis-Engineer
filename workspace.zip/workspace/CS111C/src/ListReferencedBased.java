/*Tekle Gebrezgabhier
* Assignment : linkedReferenceBaseed
* compiler Eclipse - Compiler for Java (ECJ) 
* operating system - OS MAC
*/
public class ListReferencedBased implements ListInterface {
	// reference to linked list of items

	private Node head;

	// definitions of constructors and methods

	public ListReferencedBased() {

		head = null;
	} // end default constructor

	public boolean isEmpty() {
		if (head == null)
			return true;
		else
			return false;
	}

	public int size() {
		int size = 0;
		Node curr;
		for (curr = head; curr != null; curr = curr.next)
			size++;
		return size;
	} // end size
	// }

	private Node find(int index) {
		///////////////
		// Locates a specified node in a linked list.
		// Precondition: index is the number of the desired
		// node. Assumes that 1 <= index <= size()+1
		// Postcondition: Returns a reference to the desired
		// node.
		///////////////
		// int index = ndex - 1;
		Node curr = head;
		for (int skip = 0; skip < index; skip++) {
			curr = curr.next;
		} // end for
		return curr;
	} // end find

	// get the item at the provided index
	public Comparable get(int index) throws ListIndexOutOfBoundsException {
		// int index = ndex - 1;
		if (index >= 0 && index < size()) {
			// get reference to node, then data in node
			Node curr = find(index);
			Comparable dataItem = curr.item;
			return dataItem;
		} else {
			throw new ListIndexOutOfBoundsException("List index out of bounds on get");
		} // end if
	} // end get

	// this method add item to the list item
	public void add(int ndex, Comparable item) throws ListIndexOutOfBoundsException {
		int index = ndex - 1;
		if (index >= 0 || index < size() + 1) {
			if (index == 0) {
				// insert the new node containing item at
				// beginning of list
				Node newNode = new Node(item, head);

				head = newNode;
			} else {
				Node prev = find(index - 1);

				// insert the new node containing item after
				// the node that prev references
				Node newNode = new Node(item, prev.next);
				prev.next = newNode;
			} // end if

		} else {
			throw new ListIndexOutOfBoundsException("List index out of bounds on add");
		} // end if

	} // end add
	// Remove the item from the listed item at the provided index

	public void remove(int ndex) throws ListIndexOutOfBoundsException {
		int index = ndex - 1;
		if (index >= 0 && index < size() + 1) {
			if (index == 0) {
				// delete the first node from the list
				head = head.next;
			} // end remove
			else {
				Node prev = find(index - 1);
				// delete the node after the node that prev
				// references, save reference to node
				Node curr = prev.next;
				prev.next = curr.next;
			} // end if

		} else {
			throw new ListIndexOutOfBoundsException("List index out of bounds on remove");
		} // end if
	} // end remove

	//RemoveAll operation sets the head reference to null 
	public void removeAll() {
		// setting head to null causes list to be
		// unreachable and thus marked for garbage
		// collection
		head = null;
	} // end removeAll
	
	//Returns true if the ListReferenceBased object is sorted, else returns false
	// checks that if it is sorted
	public boolean isSorted() {
		boolean sorted = true;
		for (Node curr = head; curr.next != null; curr = curr.next) {
			if (curr.item.toString().compareTo(curr.next.item.toString()) > 0) {
				sorted = false;
			}
		}

		return sorted;
	} // end isSorted
	
	
	//Adjusts the node references so that the items are in the reverse of 
    //their original order, without creating any new nodes.
	// reversed the item in the list at the provided node
	public void reverseList() {
		Node reversedPart = null;
		Node current = head;
		while (current != null) {
			Node next = current.next;
			current.next = reversedPart;
			reversedPart = current;
			current = next;
		}
		head = reversedPart;
	} // end reversed

	// node class inside in a class
	class Node {

		Comparable item;
		Node next;

		// compare Items in the nodes
		Node(Comparable newItem) {
			item = newItem;
			next = null;

		} // end constructor

		Node(Comparable newItem, Node nextNode) {
			item = newItem;
			next = nextNode;
		} // end constructor

	} // end class Node

}
