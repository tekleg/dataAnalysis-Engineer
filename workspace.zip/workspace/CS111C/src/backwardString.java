
public class backwardString {

	public static void main(String[] args) {
		writeBackward("cat");

	}
	public static void writeBackward(String s) {
	 
	//write the last character
		if(s.length()>0) {
		
		System.out.println( (s.charAt(s.length()-1)));
		//write the rest of the string	back ward
		writeBackward(s.substring(0,s.length()-1));  //recursion call
		// size=0. That is the base case do nothing
		
		}
	}

}
