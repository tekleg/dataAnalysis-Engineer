
public class BinarySearchTree<T extends KeyedItem<KT>KT extends Comparable<? super KT>>extends BinaryTreeBasis<T> {

	//BinarySearchTree.java

	//public class 
	  
	public BinarySearchTree() {
	} // end default constructor

	public BinarySearchTree(T rootItem) {
	super(rootItem);
	} // end constructor

	public void setRootItem(T newItem)
	throws UnsupportedOperationException {
	throw new UnsupportedOperationException();
	} // end setRootItem

	public void insert(T newItem) {
	root = insertItem(root, newItem);
	} // end insert

	public T retrieve(KT searchKey) {
	return retrieveItem(root, searchKey);
	} // end retrieve

	public void delete(KT searchKey) throws TreeException {
	root = deleteItem(root, searchKey);
	} // end delete

	public void delete(T item) throws TreeException {
	root = deleteItem(root, item.getKey());
	} // end delete

	protected TreeNode<T> insertItem(TreeNode<T> tNode,
	T newItem) {
	TreeNode<T> newSubtree;
	if (tNode == null) {
	// position of insertion found; insert after leaf
	// create a new node
	tNode = new TreeNode<T>(newItem, null, null);
	return tNode;
	} // end if
	T nodeItem = tNode.item;

	// search for the insertion position

	if (newItem.getKey().compareTo(nodeItem.getKey()) < 0) {
	// search the left subtree
	newSubtree = insertItem(tNode.leftChild, newItem);
	tNode.leftChild = newSubtree;
	return tNode;
	}
	else { // search the right subtree
	newSubtree = insertItem(tNode.rightChild, newItem);
	tNode.rightChild = newSubtree;
	return tNode;
	} // end if
	} // end insertItem

	protected T retrieveItem(TreeNode<T> tNode,
	KT searchKey) {
	T treeItem;
	if (tNode == null) {
	treeItem = null;
	}
	else {
	T nodeItem = tNode.item;
	if (searchKey.compareTo(nodeItem.getKey()) == 0) {
	// item is in the root of some subtree
	treeItem = tNode.item;
	}
	else if (searchKey.compareTo(nodeItem.getKey()) < 0) {
	// search the left subtree
	treeItem = retrieveItem(tNode.leftChild, searchKey);
	}
	else { // search the right subtree
	treeItem = retrieveItem(tNode.rightChild, searchKey);
	} // end if
	} // end if
	return treeItem;
	} // end retrieveItem

	protected TreeNode<T> deleteItem(TreeNode<T> tNode,
	KT searchKey) {
	// Calls: deleteNode.
	TreeNode<T> newSubtree;
	if (tNode == null) {
	throw new TreeException("TreeException: Item not found");
	}
	else {
	T nodeItem = tNode.item;
	if (searchKey.compareTo(nodeItem.getKey()) == 0) {
	// item is in the root of some subtree
	tNode = deleteNode(tNode); // delete the item
	}
	// else search for the item
	else if (searchKey.compareTo(nodeItem.getKey()) < 0) {
	// search the left subtree
	newSubtree = deleteItem(tNode.leftChild, searchKey);
	tNode.leftChild = newSubtree;
	}
	else { // search the right subtree
	newSubtree = deleteItem(tNode.rightChild, searchKey);
	tNode.rightChild = newSubtree;
	} // end if
	} // end if
	return tNode;
	} // end deleteItem

	protected TreeNode<T> deleteNode(TreeNode<T> tNode) {

	T replacementItem;

	// test for a leaf
	if ( (tNode.leftChild == null) &&
	(tNode.rightChild == null) ) {
	return null;
	} // end if leaf

	// test for no left child
	else if (tNode.leftChild == null) {
	return tNode.rightChild;
	} // end if no left child

	// test for no right child
	else if (tNode.rightChild == null) {
	return tNode.leftChild;
	} // end if no right child

	// there are two children:
	// retrieve and delete the inorder successor
	else {
	replacementItem = findLeftmost(tNode.rightChild);
	tNode.item = replacementItem;
	tNode.rightChild = deleteLeftmost(tNode.rightChild);
	return tNode;
	} // end if
	} // end deleteNode

	protected T findLeftmost(TreeNode<T> tNode) {
	if (tNode.leftChild == null) {
	return tNode.item;
	}
	else {
	return findLeftmost(tNode.leftChild);
	} // end if
	} // end findLeftmost

	protected TreeNode<T> deleteLeftmost(TreeNode<T> tNode) {
	if (tNode.leftChild == null) {
	return tNode.rightChild;
	}
	else {
	tNode.leftChild = deleteLeftmost(tNode.leftChild);
	return tNode;
	} // end if
	} // end deleteLeftmost


	public void printTree(TreeNode<T> root, int indentation){
	if(root != null){
	String indent = "";
	for (int i = 0; i < indentation; i++)
	indent += " ";
	printTree(root.rightChild, indentation + 3);
	   System.out.println(indent + root.item);
	   printTree(root.leftChild, indentation + 3);
	}
	}

	public void printInorder(TreeNode<T> root){
	if (root != null){
	printInorder(root.leftChild);
	System.out.println(root.item);
	printInorder(root.rightChild);
	}
	}

	} // end BinarySearchTree

	==============================================================

	//BinaryTreeBasis.java

	public abstract class BinaryTreeBasis<T> {
	protected TreeNode<T> root;

	public BinaryTreeBasis() {
	root = null;
	} // end default constructor

	public BinaryTreeBasis(T rootItem) {
	root = new TreeNode<T>(rootItem, null, null);
	} // end constructor

	public boolean isEmpty() {
	// Returns true if the tree
	return root == null;
	} // end isEmpty

	public void makeEmpty() {
	// Removes all nodes from the tree.
	root = null;
	} // end makeEmpty

	public T getRootItem() throws TreeException {
	// Returns the item in the tree's root.
	if (root == null) {
	throw new TreeException("TreeException: Empty tree");
	}
	else {
	return root.item;
	} // end if
	} // end getRootItem

	public abstract void setRootItem(T newItem);
	  

	} // end BinaryTreeBasis
/*
	===============================================================

	// BinaryTreeMonthes.java

	import java.io.IOException;
	import java.util.Scanner;
	import java.io.FileReader;
	import java.io.BufferedReader;
	import java.io.FileNotFoundException;

	public class BinaryTreeMonthes {
	public static void main(String[] args) throws IOException{

	BinarySearchTree<StringItem, String> tree = new BinarySearchTree<StringItem, String>();

	   System.out.println("Tree sort program");
	   System.out.print("Enter name of input file: ");
	Scanner inputFile = new Scanner(System.in);

	String inputFileName = inputFile.next();
	System.out.println();
	String input = null;

	try {
	// FileReader reads text files in the default encoding.
	FileReader fileReader = new FileReader(inputFileName);
	BufferedReader bufferedReader = new BufferedReader(fileReader);

	//put into queue.
	while((input = bufferedReader.readLine()) != null) {
	   tree.insert(new StringItem(input));
	}

	bufferedReader.close(); //close .dat
	}
	catch(FileNotFoundException ex) {
	System.out.println("Unable to open file '" + inputFileName + "'");
	}
	catch(IOException ex) {
	System.out.println("Error reading file '" + inputFileName + "'");
	}
	System.out.println("Binary search tree:\n");
	// binary search tree format
	tree.printTree(tree.root, 0);

	System.out.println('\n' + "Sorted items:" +'\n');
	//display sorted monthes
	   tree.printInorder(tree.root);
	   }
	}

	//===============================================================

	//KeyedItem.java

	public abstract class KeyedItem<KT extends Comparable<? super KT>> {

	private KT searchKey;

	public KeyedItem(KT key) {
	searchKey = key;
	} // end constructor

	public KT getKey() {
	return searchKey;
	} // end getKey

	} // end KeyedItem

	//=================================================================

	//StringItem.java

	public class StringItem extends KeyedItem<String>{
	public StringItem (String item){
	super(item);
	}

	public String toString(){
	return getKey();
	}
	} //end StringItem

	//================================================================

	//TreeException.java

	public class TreeException extends RuntimeException {
	public TreeException(String s) {
	super(s);
	} // end constructor
	} // end TreeException

	//=================================================================

	//TreeNode.java
	class TreeNode<Tree> {
	Tree item;
	TreeNode<Tree> leftChild;
	TreeNode<Tree> rightChild;

	public TreeNode(Tree newItem) {
	// Initializes tree node with item and no children.
	item = newItem;
	leftChild = null;
	rightChild = null;
	} // end constructor

	public TreeNode(Tree newItem, TreeNode<Tree> left, TreeNode<Tree> right) {
	  
	item = newItem;
	leftChild = left;
	rightChild = right;
	} // end constructor

	} // end TreeNode




