 /*
  * @ Name: Tekle Gebrezgabhier
  * Lab 2. Design and Implement an ADT for a polynomial. 
  * @  compiler Eclipse - Compiler for Java (ECJ) 
  * @ Operating system: Mac OSX  
*/

import java.util.Scanner;
public class lab2Polynomial {        // class name lab2Polynomial
	private Node first = new Node (0,0); //  keep the first node as always empty with coefficient and exponent as 0,0
	private Node last = first;
	
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx     main method  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx  
	 public static void main(String[] args) {

	    lab2Polynomial poly1 = new lab2Polynomial();
	    lab2Polynomial poly2 = new lab2Polynomial();
	    Scanner scanner = new Scanner(System.in);
	   
	   
	    System.out.println("Adds Two Polynomials and Displays The Sesult.");
	    System.out.println("Enter the first polynomial");
	    System.out.println("Enter coefficient followed by power");
	    System.out.println("for example 3 4 represents 3x^4");
	    System.out.println("Enter -1 -1 to end input");
	    
	    String line = scanner.nextLine();
	    int x = Integer.parseInt(line.split(" ")[0]);
	    int y = Integer.parseInt(line.split(" ")[1]);
	    int i=0;
	  // Keep reading from the console until user enters -1, -1
	    while (i==0) {
	         try {
	              lab2Polynomial temp = new lab2Polynomial(x, y);
	              poly1 = poly1.sum(temp);
	         } catch (InvalidPowerException e) {
	              System.out.println(e.getMessage());
	              System.out.println("Please re-enter term and continue.");
	         }
	         line = scanner.nextLine();
	         x = Integer.parseInt(line.split(" ")[0]);
	         y = Integer.parseInt(line.split(" ")[1]);
	         if (x == -1 && y == -1)
	        	 i = 1;
	    } //end of while loop
	    System.out.println("FIRST POLYNOMIAL : " + poly1.toString());
	    System.out.println( " ________________________________________________________\n");
	    System.out.println("Enter second polynomial.");
	    System.out.println("Enter each term on a separate line; coefficient followed by power.");
	    System.out.println("For example, 3 4 represents the term 3x^4.");
	    System.out.println("Enter -1 -1 to end input for the polynomial.");

	   line = scanner.nextLine();    // Same logic as explained above
	    x = Integer.parseInt(line.split(" ")[0]);
	    y = Integer.parseInt(line.split(" ")[1]);
	    
	    i= 0;
	     while ( i==0) {

	         try {
	              lab2Polynomial temp = new lab2Polynomial(x, y);
	              poly2 = poly2.sum(temp);
	         } catch (InvalidPowerException e) {
	              System.out.println(e.getMessage());
	              System.out.println("Please re-enter term and continue.");
	         }
	         line = scanner.nextLine();
	         x = Integer.parseInt(line.split(" ")[0]);
	         y = Integer.parseInt(line.split(" ")[1]);
	         if (x == -1 && y == -1)
	        	 i = 1;
	    } //end of while loop
	    System.out.println("SECOND POLYNOMIAL : " + poly2);
	    System.out.println( "___________________________________________________\n");
	    
	    System.out.println("SUM : " + poly1.sum(poly2).toString());
	    System.out.println( " __________________________________________________\n");
	     
	    System.out.println("Enter first polynomial.");
	    System.out.println("Enter each term on a separate line; coefficient followed by power.");
	    System.out.println("For example, 3 4 represents the term 3x^4.");
	    System.out.println("Enter -1 -1 to end input for the polynomial.");

	    line = scanner.nextLine();         // Same logic as explained above
	    x = Integer.parseInt(line.split(" ")[0]);
	    y = Integer.parseInt(line.split(" ")[1]);
	 
	    while (i==0) {
	         try {
	              poly1.changeCoefficient(x, y);
	         } catch (InvalidPowerException e) {
	              System.out.println(e.getMessage());
	              System.out.println("Please re-enter term and continue");
	         }
	         line = scanner.nextLine();
	         x = Integer.parseInt(line.split(" ")[0]);
	         y = Integer.parseInt(line.split(" ")[1]);
	         
	         if (x == -1 && y == -1)
	        	 i = 1;
	    } //end of while loop
	    System.out.println("First Polynomial : " + poly1);
	    System.out.print(" ");
	}  //end of the main method

	
	 private static class Node {

       int coeff ;   //Coefficient in the polynomial
        int expo ;    // Exponent in the polynomial
 Node next;  // Next will point to the Next Node

         Node(int coeff, int expo) {
              if (expo < 0) {
                   throw new InvalidPowerException("Error: cannot have negative power.");
              }
              this.coeff  = coeff ;
              this.expo  = expo ;
         }
    }

 // xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx   Default Constructor  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    private lab2Polynomial() {
    }
    // LinkedPolynomial will accept the coefficient and the exponent
    public lab2Polynomial(int coeff , int expo ) {
         last.next = new Node(coeff, expo);
         last = last.next;
    }
 //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx  Sum of two Polynomial  xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    
    public lab2Polynomial sum(lab2Polynomial polynomialB) {
         lab2Polynomial polynomialA = this;
         lab2Polynomial polynomialC = new lab2Polynomial();

         Node nodeX = polynomialA.first.next;
         Node nodeY = polynomialB.first.next;
         // Loop until the nodeX and nodeY both is not null
         while (nodeX != null || nodeY != null) {
              Node temp;
              if (nodeX == null) {
                   // if nodeX is null, we can simply put the value of nodeY in temp
                   temp = new Node(nodeY.coeff , nodeY.expo );
                   nodeY = nodeY.next;
              } else if (nodeY == null) {
              temp = new Node(nodeX.coeff , nodeX.expo );    // same as above explanation
                   nodeX = nodeX.next;
              } else if (nodeX.expo > nodeY.expo) {
                   // if nodeX exponent is greater than nodeY exponent, we keep nodeX in temp Node
                   temp = new Node(nodeX.coeff, nodeX.expo);
                   nodeX = nodeX.next;
              } else if (nodeX.expo < nodeY.expo) {
                   // same as above explanation
                   temp = new Node(nodeY.coeff, nodeY.expo);
                   nodeY = nodeY.next;
              }

              else {
                   // if coefficient of nodeX and nodeY are same, we add their coefficients
                   int coef = nodeX.coeff + nodeY.coeff;
                   int exp = nodeX.expo;
                   nodeX = nodeX.next;
                   nodeY = nodeY.next;
                   if (coef == 0)
                        continue;
                   temp = new Node(coef, exp);
              } // end of if/else
 polynomialC.last.next = temp;
              polynomialC.last = polynomialC.last.next;
         }
         return polynomialC;
    } //end of  sum of two Polynomial

  //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx  GET THE DEGREE OF THE POLYNOMIAL  xxxxxxxxxxxxxxxxxxxxxxxx
    
    public Integer degree() {
        lab2Polynomial polynomial = this;
         Integer maxDegree = polynomial.first.next.expo; // Keep maxDegree as the exponent of the first node
         Integer coefficient = 0;
        for (Node x = polynomial.first.next.next; x != null; x = x.next) {   // Loop through the polynomial
              
              if (x.expo > maxDegree) {        // We check if the next degree is greater than the maxDegree
                   maxDegree = x.expo;
                   coefficient = x.coeff;
              }
         }
         return coefficient;
    } //end of get the degree of polynomisl
	
// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx  METHOD TO GET  THE COEFFICIENT OF THE DEGREE   xxxxxxxxxxxxxxxxxxxx
	public Integer getCoefficient(int expo) {
         lab2Polynomial polynomial = this;	
 Integer coeff = null;
boolean found = false;
if(expo<0) {
	throw new InvalidPowerException("Error:cannot have negative power.");
}
//Loop through the polynomial, and check for the matching exponent
for(Node x= polynomial.first.next;x!=null;x=x.next) {
	if(x.expo==expo) {
		coeff = x.coeff;
		break;
	}
}
if (!found) {
System.out.println("Exponent " + expo + " not found in the Polynomial");

}
return coeff;

}// end of method to get coefficient of the degree

	//xxxxxxssssssssssssssssssssssssssss  METHOD TO CHANGE COEFFICIENT  ssssssssssssssssssssssssssssssssssss

public void changeCoefficient(int coeff, int expo) {
	lab2Polynomial polynomial = this; 
	boolean found = false;
if (expo < 0) {
throw new InvalidPowerException("Error: cannot have negative power."); 

}
//Loop through the polynomial, and check for the exponent entered by user. When found the exponent,
// change the coefficient of the node with the one entered by the user and break out of the loop
for(Node x = polynomial.first.next; x!= null; x = x.next) {  
	
	if(x.expo == expo) {
		x.coeff = coeff;
		break;
	}
}  //end of foor loop
if(!found) {
	System.out.println("Exponent" + expo + "not found in the polynomial");
 }
} //end of method to change coefficient

//sssssssssssssssssssssssssss  CONVERT TO STRING REPRESENTATION   sssssssssssssssssssssssssssssssssssssss
 
public String toString() {
     String printResult = "";
     boolean start = true;
     for (Node x = first.next; x != null; x = x.next) {
    	 if ((x.coeff == 1 || x.coeff == -1) && x.expo > 0) // this check the coefficient whether it is -ve or +ve
             printResult = printResult +  " + "+"-" + (x.expo == 1 ? ("x") : ("x^" + x.expo));    		 
    	 else if (x.coeff > 1)
               if (start) {
				// (x.exponent == 1 ? ("x") : ("x^" + x.exponent) = Checks
                // if exponent of x is 1, then print only x, other print x^x.exponent
                printResult = printResult + x.coeff + (x.expo == 1 ? ("x") : ("x^" + x.expo));
                start = false;
           }
			else {
                printResult = printResult + " + " + x.coeff + (x.expo == 1 ? ("x") : ("x^" + x.expo));
				//printResult = printResult + " + "   + (x.expo == 1 ? ("x") : ("x^" + x.expo));          
           }
         else if (x.coeff < 0)
           printResult = printResult + " - " + (-x.coeff) + (x.expo == -1 ? ("x") : ("x^" + x.expo)); 
 } //end of the for loop
 
 printResult = printResult.replaceFirst("(x\\^0)", ""); // Replacing the x^0 with empty string, in the string
 return printResult;
 } // end of the To String method

} //end of the lab2Polynomial class
				 