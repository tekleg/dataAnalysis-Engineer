
public class backward2 {

	public static void main(String[] args) {
		 writeBackward2("cat");

	}
public static void writeBackward2(String s) {

	System.out.println("Enter writeBackward:"+s);
	if(s.isEmpty()){
		;
	}
	else{
		writeBackward2(s.substring(1) );
		
		System.out.println("About to write first character of string:"+s);
		
		System.out.println(s.charAt(0));
	
	} //end of the if& else
	
	System.out.println("leaving writeBackward2, String:"+s);
 
} //end of the writeBackward2

}
