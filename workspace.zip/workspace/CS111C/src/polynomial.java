
 

	import java.util.Scanner;

	public class polynomial {

	     // We want to keep the first node as always empty with coefficient and exponent as 0,0
	     private Node first = new Node(0, 0);
	     private Node last = first;

	     // Node will hold the data i.e. the coefficient and the exponent of a single node
	     // e.g : 10x^3 + 5x^2 + 10
	     // So, 10x^3 will represent a node with coefficient 10, and exponent 3
	     // Inside the Inner Class Node below, Node next will hold the next node info.
	     // e.g: Node1 holds, 10x^3, Node1.next is Node2, which will hold 5x^2,... and so on
	     private static class Node {

	          // Coefficient in the polynomial
	          int coefficient;
	          // Exponent in the polynomial
	          int exponent;

	          // Next will point to the Next Node
	          Node next;

	          Node(int coefficient, int exponent) {
	               if (exponent < 0) {
	                    throw new InvalidPowerExceptions("Error: cannot have negative power.");
	               }
	               this.coefficient = coefficient;
	               this.exponent = exponent;
	          }
	     }

	     // Default Constructor
	     private polynomial() {
	     }

	     // Polynomial will accept the coefficient and the exponent
	     public polynomial(int coefficient, int exponent) {
	          last.next = new Node(coefficient, exponent);
	          last = last.next;
	     }

	     // Sum of two Polynomials
	     public polynomial sum(polynomial polynomialB) {
	          polynomial polynomialA = this;
	          polynomial polynomialC = new polynomial();

	          Node nodeX = polynomialA.first.next;
	          Node nodeY = polynomialB.first.next;
	          // Loop until the nodeX and nodeY both is not null
	          while (nodeX != null || nodeY != null) {
	               Node temp;
	               if (nodeX == null) {
	                    // if nodeX is null, we can simply put the value of nodeY in temp
	                    temp = new Node(nodeY.coefficient, nodeY.exponent);
	                    nodeY = nodeY.next;
	               } else if (nodeY == null) {
	                    // same as above explanation
	                    temp = new Node(nodeX.coefficient, nodeX.exponent);
	                    nodeX = nodeX.next;
	               } else if (nodeX.exponent > nodeY.exponent) {
	                    // if nodeX exponent is greater than nodeY exponent, we keep nodeX in temp Node
	                    temp = new Node(nodeX.coefficient, nodeX.exponent);
	                    nodeX = nodeX.next;
	               } else if (nodeX.exponent < nodeY.exponent) {
	                    // SAme as above explanation
	                    temp = new Node(nodeY.coefficient, nodeY.exponent);
	                    nodeY = nodeY.next;
	               }

	               else {
	                    // if coefficient of nodeX and nodeY are same, we add their coefficients
	                    int coef = nodeX.coefficient + nodeY.coefficient;
	                    int exp = nodeX.exponent;
	                    nodeX = nodeX.next;
	                    nodeY = nodeY.next;
	                    if (coef == 0)
	                         continue;
	                    temp = new Node(coef, exp);
	               }

	               polynomialC.last.next = temp;
	               polynomialC.last = polynomialC.last.next;
	          }
	          return polynomialC;
	     }

	     // Get the degree of the polynomial
	     public Integer degree() {
	          polynomial polynomial = this;
	          Integer maxDegree = polynomial.first.next.exponent; // Keep maxDegree as the exponent of the first node
	          Integer coefficient = 0;
	          // Loop through the polynomial
	          for (Node x = polynomial.first.next.next; x != null; x = x.next) {
	               // We check if the next node is greater than the maxDegree
	               if (x.exponent > maxDegree) {
	                    maxDegree = x.exponent;
	                    coefficient = x.coefficient;
	               }
	          }
	          return coefficient;
	     }

	     // Method to get the coefficient of a degree
	     public Integer getCoefficient(int exponent) {
	          polynomial polynomial = this;
	          Integer coefficient = null;
	          boolean found = false;
	          if (exponent < 0) {
	               throw new InvalidPowerExceptions("Error: cannot have negative power.");
	          }
	          // Loop through the polynomial, and check for the matching exponent
	          for (Node x = polynomial.first.next; x != null; x = x.next) {
	               if (x.exponent == exponent) {
	                    coefficient = x.coefficient;
	                    break;
	               }
	          }
	          if (!found) {
	               System.out.println("Exponent " + exponent + " not found in the Polynomial");
	          }
	          return coefficient;
	     }

	     // Method to change coefficient
	     public void changeCoefficient(int coefficient, int exponent) {
	          polynomial polynomial = this;
	          boolean found = false;
	          if (exponent < 0) {
	               throw new InvalidPowerExceptions("Error: cannot have negative power.");
	               
	          }
	          // Loop through the polynomial, and check for the exponent entered by user. When found the exponent,
	          // change the coefficient of the node with the one entered by the user and break out of the loop
	          for (Node x = polynomial.first.next; x != null; x = x.next) {
	               if (x.exponent == exponent) {
	                    x.coefficient = coefficient;
	                    break;
	               }
	          }
	          if (!found) {
	               System.out.println("Exponent " + exponent + " not found in the Polynomial");
	          }
	     }

	     // convert to string representation
	     public String toString() {
	          String printResult = "";
	          boolean start = true;
	          for (Node x = first.next; x != null; x = x.next) {
	               if (x.coefficient > 0)
	                    if (start) {
	                          //(x.exponent == 1 ? ("x") : ("x^" + x.exponent) = Checks
	                         //if exponent of x is 1, then print only x, other print x^x.exponent
	                         printResult = printResult + x.coefficient + (x.exponent == 1 ? ("x") : ("x^" + x.exponent));
	                         start = false;
	                    } else {
	                         printResult = printResult + " + " + x.coefficient
	                                   + (x.exponent == 1 ? ("x") : ("x^" + x.exponent));
	                    }
	               else if (x.coefficient < 0)
	                    printResult =
	                              printResult + " - " + (-x.coefficient) + (x.exponent == -1 ? ("x") : ("x^" + x.exponent));
	          }
	          // Replacing the x^0 with empty string, in the string
	          printResult = printResult.replaceFirst("(x\\^0)", "");
	          return printResult;
	     }

	     // test client
	     public static void main(String[] args) {

	          polynomial polynomial1 = new polynomial();
	          polynomial polynomial2 = new polynomial();

	          // Scanner used for reading values from Console
	          Scanner scanner = new Scanner(System.in);

	          System.out.println("-");
	          System.out.println("POLYNOMIAL ADDER");
	          System.out.println("This program adds two polynomials and displays the result.");
	          System.out.println("Enter first polynomial.");
	          System.out.println("Enter each term on a separate line; coefficient followed by power.");
	          System.out.println("For example, 3 4 represents the term 3x^4.");
	          System.out.println("Enter -1 -1 to end input for the polynomial.");

	          // Scan the next line
	          String line = scanner.nextLine();
	          // Split the string into two halves
	          // USer enters for eg 44 55, so spilt it into two halves as 44 and 55 and put it in integer
	          int x = Integer.parseInt(line.split(" ")[0]);
	          int y = Integer.parseInt(line.split(" ")[1]);
	          // Keep reading from the console until user enters -1, -1
	          while (x != -1 && y != -1) {

	               try {
	                    polynomial temp = new polynomial(x, y);
	                    polynomial1 = polynomial1.sum(temp);
	               } catch (InvalidPowerExceptions e) {
	                    System.out.println(e.getMessage());
	                    System.out.println("Please re-enter term and continue.");
	               }
	               line = scanner.nextLine();
	               x = Integer.parseInt(line.split(" ")[0]);
	               y = Integer.parseInt(line.split(" ")[1]);
	          }
	          System.out.println("FIRST POLYNOMIAL : " + polynomial1.toString());

	          System.out.println("Enter second polynomial.");
	          System.out.println("Enter each term on a separate line; coefficient followed by power.");
	          System.out.println("For example, 3 4 represents the term 3x^4.");
	          System.out.println("Enter -1 -1 to end input for the polynomial.");

	          // Same logic as explained above
	          line = scanner.nextLine();
	          x = Integer.parseInt(line.split(" ")[0]);
	          y = Integer.parseInt(line.split(" ")[1]);
	          while (x != -1 && y != -1) {

	               try {
	                    polynomial temp = new polynomial(x, y);
	                    polynomial2 = polynomial2.sum(temp);
	               } catch (InvalidPowerExceptions e) {
	                    System.out.println(e.getMessage());
	                    System.out.println("Please re-enter term and continue.");
	               }
	               line = scanner.nextLine();
	               x = Integer.parseInt(line.split(" ")[0]);
	               y = Integer.parseInt(line.split(" ")[1]);
	          }
	          System.out.println("SECOND POLYNOMIAL : " + polynomial2);
	          System.out.println("SUM : " + polynomial1.sum(polynomial2).toString());
	          System.out.println(
	                    "Here's an example with try/catch logic using the exception thrown by the changeCoefficient to detect inputs of powers that are out of range:");
	          System.out.println("Enter first polynomial.");
	          System.out.println("Enter each term on a separate line; coefficient followed by power.");
	          System.out.println("For example, 3 4 represents the term 3x^4.");
	          System.out.println("Enter -1 -1 to end input for the polynomial.");

	          // Same logic as explained above
	          line = scanner.nextLine();
	          x = Integer.parseInt(line.split(" ")[0]);
	          y = Integer.parseInt(line.split(" ")[1]);
	          while (x != -1 && y != -1) {
	               try {
	                    polynomial1.changeCoefficient(x, y);
	               } catch (InvalidPowerExceptions e) {
	                    System.out.println(e.getMessage());
	                    System.out.println("Please re-enter term and continue");
	               }
	               line = scanner.nextLine();
	               x = Integer.parseInt(line.split(" ")[0]);
	               y = Integer.parseInt(line.split(" ")[1]);
	          }
	          System.out.println("First Polynomial : " + polynomial1);
	          System.out.println("");
	     }

	}
