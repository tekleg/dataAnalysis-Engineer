/*Tekle Gebrezgabhier
 * Assignment 1c: Formula
 * compiler Eclipse - Compiler for Java (ECJ) 
 * operating system - OS MAC
 * I am using two methods the one to shows   mult3 and the second shows factorial X, but they gives same out put.
 */

public class Formula3 {  //  class is a blueprint of an object

	public static void main(String[] args) {
		// main method calls all the other methods required to run.

		System.out.println("The factorial of x! is " + fact(3));

		System.out.println("The value of x*n =  x + x*(n-1) is " + mult3(3));

	}    //end of the main method

	
	//////////////////////////////////////////////////////////////////////////////////

	// this function is used for x*n = x + x*(n-1)
	// let x=3 and n=2 the answer will be 6

	public static int mult3(int x) {
		int n = 2;
		if (x == 0)
			return 1;
		else

			return x + x * (n - 1); // this is the same for x*n = x+x(n-1) =>  3*2 = 3 + 3(2-1)
									
	}

	/////////////////////////////////////////////////////////////////////////////////////

	// this function is used for factorial x using recursion

	public static int fact(int x)

	{

		if (x == 0) { // base case for factorial x
			return 1;
		}
		if (x == 1) {
			return 1;
		}
		return x * fact(x - 1); // recursion call

	}
}
