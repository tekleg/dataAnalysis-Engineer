/*
 * Tekle Gebrezgabhier
   Assignment 1b: Triple Call Counter
   compiler Eclipse Compiler for Java (ECJ) 
   operating system  OS MAC
*/
public class TripleCallCounter {   //class is the blueprint from which individual objects are created.

	public static void main(String[] args)  
	{ 
		//main method used to nun the program by calling the the methods
		
System.out.println("T(n)=T(n-1) + T(1) + T(n-1) = " + solveTripleCounter(5)); // pass the parameter
  
	} 
	//end of main method
 	
	public static int solveTripleCounter(int n) 
	{  
		// the function  takes a single integer parameter and 
		//returns the value of the three recursive calling
		
		if(n==0)   // at n equal zero the out put will be zero
		{   
			
			return 0;
		}
		if(n==1)     //at n equal one it return one
		{
		return 1;
		}
	 return solveTripleCounter(n-1) + solveTripleCounter(1) + solveTripleCounter(n-1); // three recursion call
 }  //end of the solveTripleCounter method
}  //end of the class