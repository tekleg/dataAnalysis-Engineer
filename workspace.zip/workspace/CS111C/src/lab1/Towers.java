/*Tekle Gebrezgabhier
 * Assignment 1a: Towers of Hanoi Directions 
 * compiler Eclipse Compiler for Java (ECJ) 
 * operating system  OS MAC
 */
  public class Towers      // A class is the blueprint from which individual objects  are created.
	
	  {

	public static void main(String[] args)   // main method is a special method – Launched when you run a program

											
	{

		solveTowers(3, 'A', 'B', 'C');  // A,B,C are the poles holding the disks  A=source , B=destination ,C=spare
										

	}     //end of the main method

	public static void solveTowers(int count, char source, char destination, char spare) {

		if (count == 1) {   // if count is one disk moves from source to  destination
							
			System.out.println("Move top disk from pole " + source + " to Pole  " + destination);
		}

		else {

			solveTowers(count - 1, source, spare, destination); // recursion call used to move form source to spare
															
															
			solveTowers(1, source, destination, spare);// recursion call used to  move the disk form  source to destination
														
														
			solveTowers(count - 1, spare, destination, source);// recursion call used to move the disk from spare to destination
																
																
		} // end of the if and else

	} // end of the solveTowers

} // end of the class
