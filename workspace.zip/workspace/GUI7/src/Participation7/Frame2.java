 

package Participation7;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Frame2 extends JFrame {   //container Frame    
	private JButton clickButton;
	private JLabel l;
	private Container contentPane;
	
	
	public Frame2() {      //constructor add button and listener class to frame class
		super();
		
		setSize(200,200);
		
		contentPane=getContentPane();   //get content pane
		
		JPanel p1 = new JPanel();        //create object
		p1.setBackground(Color.YELLOW); //set color
		contentPane.add(p1) ;
		
		l=new JLabel("Hello World");  //create new JLabel object
		l.setForeground(Color.RED);
		p1.add(l);
		
		clickButton=new JButton("click");
		ButtonListener bl=new ButtonListener();
		 
		p1.add(clickButton);
		private class ButtonListener implements ActionListener {
			public void actionPerformed(ActionEvent event) {
			
		//private  class ButtonListener implements ActionListener{
		//public void actionPorfermed(ActionEvent event){
			
		}
			
			
		}
		
		
		
		
	}
	public static void main(String[]args){
		EventQueue.invokeLater(new Runnable(){
		public void run(){
		
			Frame2 f=new Frame2();   //create 
			f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			f.setVisible(true);
		}
		});
		
	}

}
