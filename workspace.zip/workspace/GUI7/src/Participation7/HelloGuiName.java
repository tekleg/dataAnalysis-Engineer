package Participation7;


	import javax.swing.*;
	import java.awt.*;
	import java.awt.event.*;

public class HelloGuiName extends JFrame{ 
		    
		    private JTextField inputName;
		    private JTextField inputAge;
		    private JLabel userName;
		    private JLabel userAge;
		    private JLabel status;
		    private JButton clickButton;
		 
			HelloGuiName() {
				// invoke the super class constructor to construct the named window
				 super("Hellow!");
				 setSize(350,350);
				 setLayout(new FlowLayout());
				
			     userName = new JLabel("What's your name? ");
				 add(userName);
				
				 inputName = new JTextField(5);
				 add(inputName);    
				
			     userAge = new JLabel(" how old are you? ");
			    		
				 add(userAge);        
				 inputAge = new JTextField(5);
				add(inputAge);
				
			    clickButton = new JButton("submit");
				add(clickButton);        
				
			    clickButton.addActionListener(new buttonListener());
				status = new JLabel("");
				add(status);
				
			}
			
			public  class  buttonListener implements ActionListener{   
				
			public void actionPerformed(ActionEvent event) {     
					
				 
					status.setText("Hello, "+inputName.getText()+"!"
							+" Next year, you will turn "
							+inputAge.getText()
							+" years old！");
							
						
				}
				}
			public static void main(String args[]){
				// create an object of your class
				HelloGuiName guiName= new HelloGuiName();
			    guiName.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			    guiName.setVisible(true);
				 
				
			}
			
		}

		




