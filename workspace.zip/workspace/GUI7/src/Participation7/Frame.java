package Participation7;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Frame extends JFrame {   //container Frame    to show how to add panel to contentPane & label to panel
	
	
	private JLabel l;
	private Container contentPane;
	
	
	public Frame() {      //constructor
		super();
		
		setSize(200,200);
		
		contentPane=getContentPane();   //get content pane
		
		JPanel p1 = new JPanel();        //create object
		p1.setBackground(Color.YELLOW); //set color
		contentPane.add(p1) ;
		
		l=new JLabel("Hello World");  //create new JLabel object
		l.setForeground(Color.RED);
		p1.add(l);
	}
	public static void main(String[]args){
		EventQueue.invokeLater(new Runnable(){
		public void run(){
		
			Frame f=new Frame();   //create 
			f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			f.setVisible(true);
		}
		});
		
	}

}
