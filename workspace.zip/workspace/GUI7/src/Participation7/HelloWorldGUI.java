package Participation7;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class HelloWorldGUI extends JFrame { 

	private JLabel helloLabel, greetingLabel;
	private JButton changeMessageButton;
	private JTextField nameInputField;
	private Container contentPane; // a reference to the content pane of the JFrame

	public HelloWorldGUI () {
		
		// invoke the super class constructor to construct the named window
		super("My First GUI");

		// set the width and height of the window (in pixels)
		setSize(200,300);

		// get the content pane add a panel to it
		// set the background color of the panel (Color.??? constants)
		contentPane = this.getContentPane();
		JPanel mainPanel = new JPanel();
		mainPanel.setBackground(Color.YELLOW);
		contentPane.add(mainPanel);

		helloLabel = new JLabel("Hello World!");
		mainPanel.add(helloLabel);
		
		greetingLabel = new JLabel("How are you?");
		greetingLabel.setForeground(Color.BLUE);
		mainPanel.add(greetingLabel);
 
		changeMessageButton = new JButton("Click to Change Text");
		mainPanel.add(changeMessageButton);
		changeMessageButton.addActionListener(new ButtonListener());
		
		nameInputField = new JTextField(10); // initialize with width (10) or default text ("Enter your name here")
		mainPanel.add(nameInputField);
		
		// setup one: program reacts to user clicking enter
		nameInputField.addActionListener(new NameFieldListener());
	

	}

	private class ButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			greetingLabel.setText("You changed the text!");
			changeMessageButton.setEnabled(false);
			
			// setup two: program responds to button click
			//String userText = nameInputField.getText();
			//greetingLabel.setText("Hello, " + userText);
			//nameInputField.setText("");
		}
	}
	
	
	// setup one: the program reacts to the user clicking "enter"
	private class NameFieldListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			String userText = nameInputField.getText();
			greetingLabel.setText("Hello, " + userText);
			nameInputField.setText("");
		}
	}


	

	public static void main(String args[]) {
	
			   EventQueue.invokeLater(new Runnable() {
				public void run() {
					// create an object of your class
					HelloWorldGUI frame = new HelloWorldGUI();
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					frame.setVisible(true);
				}
			   });

		
	}
}
 