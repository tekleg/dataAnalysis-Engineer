package homeWork7;
/*
 Assume you have a GUI program where the user selects up to three items they want to buy and then selects a shipping speed (regular or fast). The user then clicks a "purchase" button. Your program should output a summary statement, for example:

You purchased these items at regular shipping: item1 item2 item3

You purchased these items at fast shipping: item2 item3

Write the code that would go inside of the handler/listener for the button, using these components:

JCheckBox item1Checkbox
JCheckBox item2Checkbox
JCheckBox item3Checkbox
JRadioButton regularShippingSpeedRadioButton
JRadioButton fastShippingSpeedRadioButton
JTextField summaryTextField
JButton purchaseButton
For full credit, avoid repeating code and make your code as streamlined as possible.


 */
 
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class  Question18  extends JFrame { 

	private JLabel helloLabel, greetingLabel;
	private JButton changeMessageButton;
	private JTextField nameInputField;
	private Container contentPane; // a reference to the content pane of the JFrame

	public Question18  () {
		
		// invoke the super class constructor to construct the named window
		super("My First GUI");

		// set the width and height of the window (in pixels)
		setSize(200,300);

		// get the content pane add a panel to it
		// set the background color of the panel (Color.??? constants)
		contentPane = this.getContentPane();
		JPanel mainPanel = new JPanel();
		mainPanel.setBackground(Color.YELLOW);
		contentPane.add(mainPanel);

		helloLabel = new JLabel("Hello World!");
		mainPanel.add(helloLabel);
		
		greetingLabel = new JLabel("How are you?");
		greetingLabel.setForeground(Color.BLUE);
		mainPanel.add(greetingLabel);
 
		changeMessageButton = new JButton("Click to Change Text");
		mainPanel.add(changeMessageButton);
		changeMessageButton.addActionListener(new ButtonListener());
		
		nameInputField = new JTextField(10); // initialize with width (10) or default text ("Enter your name here")
		mainPanel.add(nameInputField);
		
		// setup one: program reacts to user clicking enter
		nameInputField.addActionListener(new NameFieldListener());
	

	}

	private class ButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			greetingLabel.setText("You changed the text!");
			changeMessageButton.setEnabled(false);
			
			// setup two: program responds to button click
			//String userText = nameInputField.getText();
			//greetingLabel.setText("Hello, " + userText);
			//nameInputField.setText("");
		}
	}
	
	
	// setup one: the program reacts to the user clicking "enter"
	private class NameFieldListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			String userText = nameInputField.getText();
			greetingLabel.setText("Hello, " + userText);
			nameInputField.setText("");
		}
	}


	

	public static void main(String args[]) {
	
			   EventQueue.invokeLater(new Runnable() {
				public void run() {
					// create an object of your class
					Question18  frame = new  Question18 ();
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					frame.setVisible(true);
				}
			   });

		
	}
}
 
 