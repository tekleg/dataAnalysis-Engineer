package homeWork7; //Question29

/*
 Write code fragments to create a timer object that is fired every 10 seconds. Every 10 seconds,
  select a new random number between 1 and 100 and display it to the user using a JLabel called outputLabel.

Write the timer-related code that would go in the constructor and the complete listener class.

For full credit, use a timer object of type javax.swing.Timer and a listener class that implements ActionListener. 


 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class BackgroundChangingTimer extends JFrame {

	private JLabel countLabel;
	private JPanel mainPanel;
	private javax.swing.Timer timer, colorTimer;
	private int count;
	private Container contentPane;

	public BackgroundChangingTimer() {
		super("Change Backgrount Color");
		setSize(250, 250);
		contentPane = getContentPane();
		mainPanel = new JPanel();
		mainPanel.setBackground(Color.WHITE);
		count = 0;
		countLabel = new JLabel(Integer.toString(count));
		mainPanel.add(countLabel);

		timer = new javax.swing.Timer(10000, new TimerListener());
		timer.start();

		colorTimer = new javax.swing.Timer(10000, new TimerListener());
		colorTimer.start();
	}

	private class TimerListener implements ActionListener {
		public void actionPorformed(ActionEvent event) {

			if (event.getSource() == timer) {
				count += 10;
				countLabel.setText(Integer.toString(count));

				if (count == 100) {
					timer.stop();
					colorTimer.stop();
				}
			}

			if (event.getSource() == colorTimer) {
				Random generator = new Random();
				int r = generator.nextInt(256);
				int g = generator.nextInt(256);
				int b = generator.nextInt(256);
				Color randomColor = new Color(r, g, b);
				mainPanel.setBackground(randomColor);
			}
		}
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				BackgroundChangingTimer frame = new BackgroundChangingTimer();
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
			}
		});

	}
}
