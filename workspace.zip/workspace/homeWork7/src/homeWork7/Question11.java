package homeWork7;
/*
 Assume you have a GUI program with two text fields, a + button and a - button. The user should type a number 
 into each text field. When they click one of the buttons, either the sum or difference is then calculated and 
 displayed. The user can then no longer click either button.

Write the code that would inside of a single handler/listener for both buttons. Use the following objects:

JTextField inputNumber1TextField
JTextField inputNumber2TextField
JButton plusButton
JButton minusButton
JTextField resultTextField


1     2

3

1

 */

public class Question11 {

}
