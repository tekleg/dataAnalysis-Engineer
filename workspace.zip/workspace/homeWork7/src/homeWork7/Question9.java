package homeWork7;
/*
 Briefly explain what the following listener code will does. Assume you have the following components. 

JTextField input;

JLabel output;

The listener class is registered to input. The original text displayed in input is 
"Enter something here" and the original text displayed in output is "waiting".

 

 public class InputFieldListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {

              String inputText = input.getText();

              boolean correct = inputText.equalsIgnoreCase("something") ? true : false;

              output.setText(correct ?  "you got it" : "not quite");

              if(correct) {

                   input.setEditable(false);

              }

        }

   }   


 */
public class Question9 {

}
