package homeWork7;

/*
 Assume you have a GUI program where the user types text into one text box, clicks a button,
  and the text disappears from that text box and appears in a second text box. Write the code that
   would go inside of the handler/listener for the button. Use these references:

JTextField userInputTextField
JTextField outputTextField
JButton submitButton

String message;

message = userInputTextField.getText();
userInputTextField.setText("");
outputTextField.setText(message);

 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Question10 extends JFrame {

	private JLabel helloLabel, greetingLabel;
	private JButton submitButton;
	private JTextField userInputTextField;
	private JTextField outputTextField;
	private Container contentPane;

	public Question10() {

		super("Home Work 7.");

		setSize(200, 300);

		contentPane = this.getContentPane();
		JPanel mainPanel = new JPanel();
		mainPanel.setBackground(Color.YELLOW);
		contentPane.add(mainPanel);

		helloLabel = new JLabel("Question 10!");
		mainPanel.add(helloLabel);

		
		userInputTextField = new JTextField(10);
		mainPanel.add(userInputTextField);

		outputTextField = new JTextField(10);
		mainPanel.add(outputTextField);
		submitButton = new JButton("click");
		mainPanel.add(submitButton);
		submitButton.addActionListener(new ButtonListener());
	}

	private class ButtonListener implements ActionListener {

		public void actionPerformed(ActionEvent event) {

			String input = userInputTextField.getText();
			userInputTextField.getText();
			outputTextField.setText(input);
			
			
			 
		}
	}

	public static void main(String args[]) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {

				Question10 frame = new Question10();
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
			}
		});

	}
}
