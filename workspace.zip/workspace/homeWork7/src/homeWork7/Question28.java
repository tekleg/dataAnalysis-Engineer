package homeWork7;
/*
 You have a GUI that keeps track of a list of pre-specified "special" points. If the user's 
 mouse moves over one of these points, the point lights up. Write the code that would go inside
  of the handler/listener below. Use the references and also assume the existence of the method 
  listed below (which you can invoke- you do not need to write).

specialPointList // an ArrayList of the pre-specified "special" points; the type is ArrayList<Point>
assume this method exists: public void lightUpAPoint(Point p)
Your code will go inside the handler method:

public void mouseMoved(MouseEvent event) {

 

}
jjj=

lightUpAPoint( jjj)
 */
public class Question28 {

}
