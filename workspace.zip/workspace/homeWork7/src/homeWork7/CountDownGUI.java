package homeWork7;

 
	import java.awt.*;
	import java.awt.event.*;
	import javax.swing.*;
	import java.util.*;

	public class CountDownGUI extends JFrame { 

		private JLabel countLabel;
		private JButton pauseButton, resumeButton;
		private javax.swing.Timer timer, colorTimer;
		private int count;

		private Container contentPane; // a reference to the content pane of the JFrame

		// the constructor- has the same name as the class
		public CountDownGUI () {
			// invoke the super class constructor to construct the named window
			super("Count Down!");

			// set the width and height of the window (in pixels)
			setSize(200,200);

			// get the content pane add a panel to it
			// set the background color of the panel (Color.??? constants)
			contentPane = getContentPane();
			JPanel mainPanel = new JPanel();
			mainPanel.setBackground(Color.WHITE);
			contentPane.add(mainPanel);

			count = 60;
			
			countLabel = new JLabel(Integer.toString(count));
			mainPanel.add(countLabel);
			
			timer = new javax.swing.Timer(1000, new TimerListener());
			timer.start();
			
			colorTimer = new javax.swing.Timer(5000, new TimerListener());
			colorTimer.start();
			
			pauseButton = new JButton("Pause");
			mainPanel.add(pauseButton);
			pauseButton.addActionListener(new ButtonListener());

			resumeButton = new JButton("Resume");
			resumeButton.setEnabled(false);
			mainPanel.add(resumeButton);
			resumeButton.addActionListener(new ButtonListener());
		}
		
		private class ButtonListener implements ActionListener {
			public void actionPerformed(ActionEvent event) {
				if(event.getSource()==pauseButton) {
					timer.stop();
					colorTimer.stop();
					resumeButton.setEnabled(true);
					pauseButton.setEnabled(false);
				} else if(event.getSource()==resumeButton) {
					timer.start();
					colorTimer.start();
					resumeButton.setEnabled(false);
					pauseButton.setEnabled(true);
				}
			}
		}
		
		private class TimerListener implements ActionListener {
			public void actionPerformed(ActionEvent event) {
				if(event.getSource()==timer) {
					count--;
					countLabel.setText(Integer.toString(count));
				
					if(count==0) {
						timer.stop();
					}
				}
				
				if(event.getSource() == colorTimer) {
					Random generator = new Random();
					int r = generator.nextInt(256);
					int g = generator.nextInt(256);
					int b = generator.nextInt(256);
					Color randomColor = new Color(r,g,b);
					countLabel.setForeground(randomColor);
				}
			}
		}

		public static void main(String args[]) {
		
				   EventQueue.invokeLater(new Runnable() {
					public void run() {
						// create an object of your class
						CountDownGUI frame = new CountDownGUI();
						frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						frame.setVisible(true);
					}
				   });

			
		}
	}

