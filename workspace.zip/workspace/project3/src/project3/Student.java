
// TEKLE GEBREZGABHIER & NEIL PRABU

package project3;

public class Student {
	
	// instance data variables/////////////////////////
	 
	private String name;
    private String ID;
    private boolean Paid;
    private final boolean DEFAULT_PAID_STATUS = true;
    
   
 // constructor  ///////////////////////
    public Student(String initialName, String initialID){ 
	name = initialName;
         ID = initialID;
         Paid = DEFAULT_PAID_STATUS;
}
   
 // getters  ////////////////////////
    
    public String getName(){
         return name;
    }
    public String getID(){
    return ID; 
    }
    public boolean isPaid(){
         return Paid;
}
    
 // setters ////////////////////////
public void setName(String newName){ name = newName;
    }
    public void setID(String newID){
ID = newID;
}
public void setPaid(boolean newPaid){
         if(newPaid == true){
               Paid = newPaid;
} else {
System.out.println("Your tution is not paid");
} 
}


//toString method   /////////////////
public String toString(){
 String s = "Name: " + name +
" \tId: " + ID;
 return s;
}
}