package palindomeInterface;

public interface palindroomInterface {
 
	int howManyLetters();
	 
 
}
