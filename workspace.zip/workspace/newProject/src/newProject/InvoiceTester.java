package newProject;

public class InvoiceTester {

	public static void main(String[] args) {
	
		Invoice inv1 = new Invoice("W1234", 67.7);
		Invoice inv2 = new Invoice("W1235", 68.7);
				
		Customer cus1 = new Customer("johone",inv1);
		Customer cus2 = new Customer("bob", inv2);
		//System.out.println(inv1.get());
		System.out.println(cus1.toString());
		System.out.println(cus2.toString());
		System.out.println(cus1.addInvoice(inv1));
	}

}
