package newProject;

public class Homework6Practice {

public static void main (String [] args)	{

System.out.println(addNumbers(4,5,8,12));   /// how to return
}
public static double addNumbers(int s1, int s2) {  //fitst method

double sum= ((double)(s1 + s2)/2);

return sum;
}

public static double  addNumbers(int s1, int s2, int s3){   //second method

double sum= ((double)(s1 + s2+ s3)/3);

return sum;
}

public static double  addNumbers(int s1, int s2, int s3, int s4){  //third method

double sum= ((double)(s1 + s2+ s3 + s4)/4);

return sum;
}

}



