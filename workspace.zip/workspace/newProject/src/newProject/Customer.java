package newProject;
import java.util.*;
public class Customer {

private String name;

private ArrayList<Invoice> invoiceList;

 

public Customer(String name) {

this.name = name;

invoiceList = new ArrayList<Invoice>();

} 
public Customer(String name, Invoice item){
this.name = name;
invoiceList = new ArrayList<Invoice>();
invoiceList.add(item);
}
public String getName(){
	return name;
}
public ArrayList<Invoice> getList(){
	return  invoiceList;
}
public void setName(String newName){
	name= newName;
}
public void set(ArrayList<Invoice> list){
	list = new ArrayList<Invoice>();	
}

public String toString(){

String s = "The customer name is " + name + 

"\nThe number of invoices for that customer is " + invoiceList.size();

return s;

 }

public boolean addInvoice(Invoice i) { 
     
	if(!invoiceList.isEmpty()){
      
	invoiceList.add(i);
      
	return true;
     
	}
     
	else {
      
	return false;
    
	}
  
}
  
 // System.out.println(invoiceList.add(s1));

}
