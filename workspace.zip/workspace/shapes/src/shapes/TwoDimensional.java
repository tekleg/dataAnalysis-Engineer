package shapes;

public class TwoDimensional extends Shapes   {

}
