package shapes;

public class Circle extends Ellipes{

}
