package shapes;

public class Ellipes extends TwoDimensional{

}
