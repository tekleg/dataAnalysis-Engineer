package shapes;

public interface Area {
	double area();  //calculates and returns 

}
