
public class School {
private String name;
}
