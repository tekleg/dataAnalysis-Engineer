
 
public abstract class Employee implements Comparable<Employee>{

	private String name, id, phone;
	private Address address;
	
	private final double RAISE_RATE = 0.04;
	
	
	public Employee(String initialName, String initialId, String initialPhone,
			Address initialAddress) {
		name = initialName;
		id = initialId;
		phone = initialPhone;
		address = initialAddress;
	}
	public Employee(String initialName, String initialId, String initialPhone,
			String street, String city, String state, int zip) {
		
		this(initialName, initialId, initialPhone, new Address(street, city, state, zip));

	}
	
	// getters
	public String getName() {
		return name;
	}
	public String getId() {
		return id;
	}
	public String getPhone() {
		return phone;
	}
	public Address getAddress() {
		return address;
	}

	
	// setters
	public void setName(String newName) {
		name = newName;
	}
	public void setPhone(String newPhone) {
		phone = newPhone;
	}
	public void setAddress(Address newAddress) {
		address = newAddress;
	}
	
	
	@Override
	public String toString() {
		String s = "Name = " + name +
				"\n\tID: " + id + 
				"\n\tPhone: " + phone +
				"\n\tAddress: " + address.toString();
		return s;
				
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Employee) {
			Employee otherEmp = (Employee) obj;
			
			boolean sameName = this.name.equalsIgnoreCase(otherEmp.name);
			boolean sameId = this.id.equalsIgnoreCase(otherEmp.id);
			boolean samePhone = this.phone.equalsIgnoreCase(otherEmp.phone);
			boolean sameAddress = this.address.equals(otherEmp.address);
			
			return sameName && sameId && samePhone && sameAddress;
			
			
		} else {
			return false;
		}
	}
	
	public abstract void pay();
	
	public void benefits() {
		System.out.println(name + " is being issued benefits.");
	}

	@Override
	public int compareTo(Employee otherEmployee) {
		if(this.name.compareToIgnoreCase(otherEmployee.name) == 0) { // names are the same
			return this.id.compareToIgnoreCase(otherEmployee.id); // compare based on id
		} else { // names are different
			return this.name.compareToIgnoreCase(otherEmployee.name);
		}
		
	}
	
	
	
	
	
	
	
	
	
	
}
