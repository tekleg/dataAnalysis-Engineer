
public class PrivateSchool {

}
