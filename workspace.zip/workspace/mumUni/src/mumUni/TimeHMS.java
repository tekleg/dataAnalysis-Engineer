package mumUni;

import java.util.Scanner;

public class TimeHMS {
	public static void main(String[]args){
System.out.println(computeHMS(12345));
}
public static int[] computeHMS(int seconds)
{
	 
    int secondsData = 3600;
    int[] arr = new int[3];

    for (int i = 0; i < arr.length; i++)
    {
        arr[i] = seconds / secondsData;
        seconds = seconds % secondsData;
        secondsData = secondsData / 60;
    }
    return arr;
}
}