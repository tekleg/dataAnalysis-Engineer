
	 /*2.
 Define an array to be a Martian array if the number of 1s is greater
 than the number of 2s and no two adjacent elements are equal. Write a 
 function named isMartian that returns 1 if its array argument is 
 a Martian array, otherwise it returns 0.
There are two additional requirements.


1. You should return 0 as soon as it is known that the array is not 
a Martian array; continuing to analyze the array would be a waste of CPU cycles.
2. There should be exactly one for loop in your function

*/
	 
package mumUni;

public class Mum2 {
	

		public static void main(String[] args) {
			 
			System.out.println(isMartian(new int[] { 1, 3 }));
			System.out.println(isMartian(new int[] { 1, 2, 1, 2, 1, 2, 1, 2, 1 }));
			System.out.println(isMartian(new int[] { 1, 3, 2 }));
			System.out.println(isMartian(new int[] { 1, 3, 3, 2, 1 }));
			System.out.println(isMartian(new int[] { 1, 2, -18, -18, 1, 2 }));
			System.out.println(isMartian(new int[] {}));
			System.out.println(isMartian(new int[] { 1 }));
			System.out.println(isMartian(new int[] { 2 }));

		}

		public static int isMartian(int[] a) {

			int counter1 = 0;
			int counter2 = 0;

			for (int i = 0; i < a.length; i++) {

				if (i < a.length - 1 && a[i] == a[i + 1]) {
					return 0;
				}
				if (a[i] == 1) {
					counter1++;
				}
				else if (a[i] == 2) {
					counter2++;
				}

			}
			if (counter1 <= counter2) {
				return 0;
			}

			return 1;
		}
	}


