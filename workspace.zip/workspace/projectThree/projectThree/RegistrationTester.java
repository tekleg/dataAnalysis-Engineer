   



    package projectThree;
    import java.util.*;
    import java.util.ArrayList;
    public class RegistrationTester {

	   public static void main(String[] args) {
		
		
//.........List of student object.....................................

		 
		Student student1 = new Student(" Carlos David", "W12343"); 
		Student student2 = new Student(" Agosta Jose" , "W34567");
		
		Student student3 = new Student(" Paul Johne " , "W34657");
		
		Student student4 = new Student(" Havier Mario", "F23453");
		
		Student student5 = new Student(" Juli Zedan"  , "W26708");
		
		Student student6 = new Student(" Jone Tom"   ,  "G43126");
		
		
		Course course1 = new Course("Computer Science ", 5); 
		
		
		  
		 
		System.out.println("//***** PRINTS THE COURSE *****");
		System.out.println();
		System.out.println(course1);
		System.out.println();
		
		///////////////////////////// BEFORE ADDING STUDENT TO THE ROSTER.../////////////////////// 
		
		System.out.println("//PRINTS THE ROSTER BEFORE ADDING STUDENT");
		System.out.println();
		course1.printRoster();
		System.out.println();
		
		
	//..................ADD STUDENTS TO THE COURSE1........................................................	System.out.println(); 
		course1.addStudent(student1); 
		course1.addStudent(student2); 
		course1.addStudent(student3);
		course1.addStudent(student4);
		course1.addStudent(student5);
		course1.addStudent(student6);
		
//................TRIES TO ADD THE 6th STUDENT...........................................................
		
		System.out.println("//TRIES TO ADD THE 6th STUDENT"); 
		System.out.println();
		course1.addStudent(student6);
		
		if(!course1.addStudent(student6)){
		System.out.println(student6 + " couldn't be added"); 
		}
		System.out.println();
		 

//................PRINTS THE ROSTER(BEFORE DROPPING 3RD STUDENT.............................................		
		
		System.out.println("//PRINTS THE ROSTER(BEFORE DROPPING 3RD STUDENT");
		System.out.println();
		course1.printRoster();
		System.out.println();
		 
		
		System.out.println("//PRINTS THE ROSTER(AFTER DROPPING 3RD STUDENT");
		System.out.println();
		course1.dropStudent(student3); 
		course1.printRoster();
		System.out.println();
		 
		
		System.out.println("//PRINTS THE ROSTER(AFTER ADDING 6TH STUDENT");
		System.out.println();
		course1.addStudent(student6); 
		course1.printRoster();
		System.out.println("\n\n");

//............. THE CODE BELOW ARE FOR COURSEAL CLASS USING ARRAY LIST.............................................
		ArrayList<Student>roster = new ArrayList<Student>(); 
		
		CourseAL course2 = new CourseAL(" Mathematics  ", 5);

		System.out.println("//***** PRINTS THE SECOND COURSE `*****");
		System.out.println("\n"+course2);
		System.out.println("\n//.....PRINTS THE ROSTER BEFORE ADDING STUDENT....");
		 course2.printRoster();
		//Add student to the course2
		System.out.println("\n//......TRIES TO ADD THE 6th STUDENT...."); 
		if(!course1.addStudent(student6)){
		System.out.println("\n"+ student6 + " couldn't be added"); }
		 
		
	   System.out.println("\n");
		//course2.printRoster();
		roster.add( student1); 
		roster.add(student2);
		roster.add(student3); 
		roster.add(student4);
		roster.add(student5); 
		roster.add(student6);
		//course2.addStudents(student6);
		
		 
		
		System.out.println("//PRINTS THE ROSTER (BEFORE DROPPING 4th STUDENT");
		System.out.println();course1.printRoster();
		System.out.println("\n//PRINTS THE ROSTER (AFTER DROPPING 4th STUDENT");
		roster.add(student4);
		course1.dropStudent(student4);
		course1.printRoster();
		System.out.println();
		System.out.println("//PRINTS THE ROSTER (AFTER ADDING 6TH STUDENT");
		course1.addStudent(student6);
		roster.add(student6);
		course1.printRoster();
		System.out.println("\nHAVE YOU GOOG DAY!");
		} 
		}
