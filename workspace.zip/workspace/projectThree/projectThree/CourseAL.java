       package projectThree;
	   import java.util.ArrayList;
	   public class CourseAL {
	    private String courseName;
	    private int numberOfStudent;
	    private ArrayList<Student>roster;
	    private static int count = 0;
		
	    private static final int SIZE_COURSE = 5;
	   
	   // .........CONSTRUCTOR...................
	    public CourseAL(String initialCourseName, int initialNumberOfStudent){ 
	    courseName = initialCourseName;
	    numberOfStudent = initialNumberOfStudent;
	  
	    
	    ArrayList<Student>roster = new ArrayList<Student>(numberOfStudent);
	    
	    }
	    
	  
	    //............GETTERS......................
	         public String getName(){
	              return courseName;
	         }
	         public int getCourseSize(){
	              return numberOfStudent;
	    }
	         
	    //.........SETTERS...........................     
	    public void setCourseName(String newCourseName){ 
	    	courseName = newCourseName;
	    }
	    public void setCourseSize(int newNumberOfStudent){
	              if(newNumberOfStudent > 0){
	            	  numberOfStudent = newNumberOfStudent;
	    } else {
	    System.out.println("Invalid number Of Student.");
	   
	    } 
	 
	    }
	  
	    //..........TOSTRING.............
	    public String toString(){
	    String s = "Course Name: " + courseName +
	    "Number of students: " + numberOfStudent; 
	    return s;
	    }

	   
	    public boolean addStudents2(ArrayList<Student>s){ 
	       ArrayList<Student>roster = new ArrayList<Student>();
	    	boolean keepPaid= true;
	    	if(keepPaid){
	    			
	         for(int i = 0; i < roster.size(); i++){
	         if(roster.get(0)==null){
	        	 //&& roster.equals(roster.size())){
	        	 
	          roster= s ;
	           count++;
	           return true;
	      } 
	     }	
	    } 
	    System.out.println("student" + count); 
	            return false;
	    }
	    public boolean dropStudent(Student s){ 
	     
	    	for(int i=0; i < roster.size(); i++){
	     
	    	if(roster !=null) {
	    			//&& roster .equals(s)) { 
	    	
	    	roster =null;
	           
	    	count--;
	            
	    	return true;
	         } 
	    }
	    //System.out.println("student" + count); 
	     return false;
	    }

	    public void printRoster(){
	       if(roster ==null){
	    System.out.println("--No student enrolled--"); } 
	       else {
	    System.out.println("Enrollment " + count); 
	    for(int i=0; i<roster.size(); i++){
	    if(roster !=null){ System.out.println(roster );
	      
	      }
	      
	      }
	     
	     }
	    
	    }
	    
	   }
