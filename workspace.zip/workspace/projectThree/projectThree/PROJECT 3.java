 
package projectThree;

import java.util.ArrayList;

public class Course {

///////// instance data variables /////////////////////
	private String courseName;
    private int numberOfStudent;
    private Student[]roster;
    private static int count = 0;
    private final int MAX_NUMBER_ENROLLED_IN_THE_COURSE = 5;
    
 // constructor  ///////////////////////
  public Course(String initialCourseName, int initialNumberOfStudent){ 
courseName = initialCourseName;
numberOfStudent = initialNumberOfStudent;
roster = new Student[numberOfStudent];
     }
  
//getters  ////////////////////////
     public String getName(){
          return courseName;
     }
     public int getCourseSize(){
          return numberOfStudent;
}
     
  // setters ////////////////////////
public void setCourseName(String newCourseName){ 
	courseName = newCourseName;
}
public void setCourseSize(int newNumberOfStudent){
          if(newNumberOfStudent > 0){
        	  numberOfStudent = newNumberOfStudent;
} else {
System.out.println("Invalid number Of Student.");
} 
}

//toString method   /////////////////
public String toString(){
String s = "Course Name: " + courseName +
" Number of students: " + numberOfStudent; 
return s;
}
 

// Other Methods  ////////////////
public boolean addStudent(Student s){ 
	if(s.isPaid() == true){
     for(int i = 0; i < roster.length; i++){
     if(roster[i]==null){

       roster[i] = s;
       count++;
       return true;
  } 
 }	
} 
//System.out.println("student" + count); 
        return false;
}
public boolean dropStudent(Student s){ 
 
	for(int i=0; i < roster.length; i++){
 
	if(roster[i]!=null && roster[i].equals(s)) { 
	
	roster[i]=null;
       
	count--;
        
	return true;
     } 
}
//..System.out.println("student" + count); 
 return false;
}

public void printRoster(){
   if(roster[0]==null){
System.out.println("--No student enrolled--"); } 
   else {
System.out.println("Enrollment " + count); 
for(int i=0; i<roster.length; i++){
if(roster[i]!=null){ 
	System.out.println(roster[i]);
  }
 
   } 
  
   }
  
 }
}