/*
 
1. Define an array to be a is121Rrray if all elements are either 1 or 2 
and it begins with one or more 1s followed by a one or more 2s and then ends with 
the same number of 1s that it begins with. Write a method named is121Array that 
returns 1 if its array argument is a 121 array, otherwise, it returns 0.
There is one additional requirement. You should return 0 as soon as it is known 
that the array is not a 121 array; continuing to analyze the array would be a waste of CPU cycles.
 */

public class mum222 {

	public static void main(String[] args) {

		//int[] a = { 2, 2,2  };

	
          
       // System.out.println(is121Array(new int[]{ 1,2,1}));
        System.out.println(is121Array(new int[]{1,1,2,2,2,1,1}));
       // System.out.println(is121Array(new int[]{ 1, 1, 2, 2, 2, 1,1,1}));
        //System.out.println(is121Array(new int[]{ 1, 1, 2, 1, 2, 1,1}));
	    //System.out.println(is121Array(new int[]{1, 1, 1, 2, 2, 2,1, 1, 1, 3 }));
	    //System.out.println(is121Array(new int[]{1, 1, 1, 1, 1, 1 }));
	   // System.out.println(is121Array(new int[]{ 2, 2, 2, 1, 1, 1,2, 2, 2, 1, 1}));
	   // System.out.println(is121Array(new int[]{ 1, 1, 1, 2, 2, 2,1, 1, 2, 2}));
	   // System.out.println(is121Array(new int[]{2, 2, 2}));
	 	  
	 
		//is121Array(a);
		//System.out.print( is121Array(a));
	}

	public static int  is121Array(int[] a) {

		int counter = 0;
		int front1s = 0;
		int back1s = 0;
		int firstIndex = -1;
		int lastIndex = -1;
		boolean consecutive = true;

		for (int i = 1; i < a.length; i++) {
			if (a[i] == 2) {
				lastIndex = i;
				counter++;
			}
		}
		if (counter >= 1) {
			for (int j = lastIndex; j >= 1; j--) {
				if (a[j] == 2)
					firstIndex = j;
			}
			for (int k = firstIndex; k < lastIndex; k++) {
				if (a[k] == 2)
					consecutive=false;	   // check again
				return 0;
			}
		}
		for (int i = 0; i < firstIndex; i++) {
			if (a[i] == 1)
				front1s++;
		}
		for (int i = lastIndex + 1; i < a.length; i++) {
			if (a[i] == 1)
				back1s++;
		}
		if (consecutive == true && front1s == back1s) {
			 
			return 1;
		}
		return 0;

	}
}
