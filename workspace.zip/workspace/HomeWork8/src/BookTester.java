
public class BookTester {

	public static void main(String[] args) {

		Book b1 = new Book("java", "ccsf", 2000);
		Book b2 = new Book("java2", "ccsf", 2016);

		Dictionary dic1 = new Dictionary("Oxford English Dictionary ", 
				        "Dr. William Chester ", 1928, " 171,476 words.");
		
		Dictionary dic2 = new Dictionary("Dictionary ", "Merriam-Webster ", 
				2015,"171,500 words");
				

		b1.getTitle();
		b2.getAuthor();
		dic2.define();
		dic1.getCopyrightYear();
		dic2.getTitle();
		
		System.out.println(b1.toString());
		System.out.println(b2.toString());

		System.out.println(dic1.toString());
		System.out.println(dic2.toString());

		System.out.println(b1.equals(b2));
		System.out.println(dic1.equals(dic2));
	}
}