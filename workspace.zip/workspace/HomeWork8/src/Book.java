
public class Book {

	protected String title;
	private String author;
	private int copyrightYear;

	public Book(String title, String author, int copyrightYear) {

		this.title = title;
		this.author = author;
		this.copyrightYear = copyrightYear;

	}

	public String getTitle() {

		return title;

	}

	public String getAuthor() {

		return author;

	}

	public int getCopyrightYear() {

		return copyrightYear;

	}

	public void setAuthor(String author) {

		this.author = author;

	}

	public void setTitle(String title) {

		this.title = title;

	}

	public void setCopyrightYear(int copyrightYear) {

		if (copyrightYear > 0) {

			this.copyrightYear = copyrightYear;

		}

	}

	@Override
	public String toString() {

		return title + " by " + author + " (" + copyrightYear + ")";

	}

	@Override
	public boolean equals(Object abj) {

		if (abj instanceof Book) {
			
			Book otherBook = (Book) abj;
			
			return this.title.equalsIgnoreCase(otherBook.title) && 
					this.author.equalsIgnoreCase(otherBook.author) && 
					this.copyrightYear == (otherBook.copyrightYear);
		} 
		else {
			return false;
		}
	}

}
