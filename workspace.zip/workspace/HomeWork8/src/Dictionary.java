
public class Dictionary extends Book {

	// title, author, int copyrightYear are inherited from Book

	String numberOfWords;

	public Dictionary(String title, String author, int copyrightYear, String numberOfWords) {

		super(title, author, copyrightYear);

		this.numberOfWords = numberOfWords;

	}

	public String getNumOfWords() {

		return numberOfWords;
	}

	public void setNumOfWords(String page, String numberOfWords) {

		this.numberOfWords = numberOfWords;
	}

	public String toString() {

		String s = super.toString();

		return s += " contains " + numberOfWords;
	}

	public void define() {
		System.out.println(
				title + " is a book that lists the words in " +
		       " alphabetical order and gives their meaning.");
	}
}
