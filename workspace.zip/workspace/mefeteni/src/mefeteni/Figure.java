package mefeteni;

public class Figure { 

public void display() {
System.out.print("Figure");
}
} 
 
 
