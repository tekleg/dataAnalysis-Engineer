package mefeteni;

public class MyClass {
 
		int num;

		public MyClass() {

		num = 5;

		}

		public void doSomething(int num) {

		System.out.print(this.num);

		System.out.print(num);

		}

		}

