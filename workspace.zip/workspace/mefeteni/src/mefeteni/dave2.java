package mefeteni;

public class dave2 {
	public static void main(String[]args) {
		System.out.println(dave2.isConsectiveFactored(24));
		
		
		System.out.println(isConsectiveFactored(105));
		System.out.println(isConsectiveFactored(90));
		System.out.println(isConsectiveFactored(23));
		System.out.println(isConsectiveFactored(15));
		System.out.println(isConsectiveFactored(2));
		System.out.println(isConsectiveFactored(0));
		System.out.println(isConsectiveFactored(-12));
	}

	public static int isConsectiveFactored(int n) {
		
		
		if (n % 2 != 0)

			return 0;

		for (int i = 2; i < n; i++) {

			int div = i * (i + 1);

			if (n % div == 0) {

				return 1;
			}

		}

		return 0;
	}
}


 