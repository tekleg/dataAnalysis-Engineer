package mefeteni;

public class dave3 {
	public static void main(String[] args) {

		System.out.println(isTwinPrime(5));
		System.out.println(isTwinPrime(7));
		System.out.println(isTwinPrime(53));
		System.out.println(isTwinPrime(9));
	}

	public static int isTwinPrime(int n) {
		int count = 0;
		for (int i = 2; i < n; i++) {
			if (n % i == 0)
				count++;
		}

		if (count == 0) {

			for (int j = 2; j < n + 2; j++) {
				if ((n + 2) % j == 0)
					count++;
			}
			if (count == 0)
				return 1;

			count = 0;
			for (int k = 2; k < n - 2; k++) {
				if ((n - 2) % k == 0)
					count++;
			}
			if (count == 0)
				return 1;

		    
		}

		return 0;
	}
}
