package mefeteni;

public class MyClassTester {

	public static void main(String[] args) {
		MyClass myClass = new MyClass();

		myClass.doSomething(3);

		/*
you now decide to include a counter to keep track of how many Customer objects have been created.Write:

the declaration of a variable to keep track of this information
the code that would be placed inside the Customer construtor
a getter method for this variable
Note: You are not counting how many invoices a customer has. You are counting how many customers there are.
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
 
		 

 Write a method called addInvoice that adds a new invoice to the customer.
 
 
 
 
  public boolean addInvoice(Invoice i) { 
       if(!invoiceList.isEmpty()){
        invoiceList.add(i);
        return true;
        }
        else{
        return false;
        }
    }
    
    System.out.println(invoiceList.add(s1));
 
 
 
 
 
 
 */
		/*
 Write an enumerated data type that describes an invoice's status as paid, due, or past due. 

(You do not need to keep track of any other information about the status.)


		 */
	}

}
