package mefeteni;

public class dave1 {
	public static void main(String[] args) {
		System.out.println(isHollow(new int[] { 1, 2, 0, 0, 0, 3, 4 }));
		System.out.println(isHollow(new int[] { 1, 1, 1, 1, 0, 0, 0, 0, 0, 2, 1, 2, 18 }));
		System.out.println(isHollow(new int[] { 1, 2, 0, 0, 3, 4 }));
		System.out.println(isHollow(new int[] { 1, 2, 0, 0, 0, 3, 4, 5 }));
		System.out.println(isHollow(new int[] { 3, 8, 3, 0, 0, 0, 3, 3 }));
		System.out.println(isHollow(new int[] { 1, 2, 0, 0, 0, 3, 4, 0 }));
		System.out.println(isHollow(new int[] { 0, 1, 2, 0, 0, 0, 3, 4 }));
		System.out.println(isHollow(new int[] { 0, 0, 0 }));
	}

	public static int isHollow(int[] a) {
		int counter = 0;
		int firstIndex = -1;
		int lastIndex = -1;
		boolean consecutive = true;
		for (int i = 0; i < a.length; i++) {
			if (a[i] == 0) {
				lastIndex = i;
				counter++;
			}
		}
		if (counter >= 3) {
			for (int j = lastIndex; j >= 0; j--) {
				if (a[j] == 0)
					firstIndex = j;
			}
			for (int k = firstIndex + 1; k < lastIndex; k++) {
				if (a[k] != 0)
				 
				consecutive = false;
			}
		}
		if (consecutive == true && (firstIndex - 0 == (a.length - lastIndex) - 1)) {
			return 1;
		}
		return 0;
	}
}
