package mefeteni;

public class Rectangle extends Figure { 

public void display() {
super.display();
 System.out.print("Rectangle");
} 
}
