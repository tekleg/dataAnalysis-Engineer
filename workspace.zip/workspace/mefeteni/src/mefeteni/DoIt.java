package mefeteni;

 
public class DoIt {

public static void main(String[ ] args) {
Figure f = new Rectangle(); 
f.display(); 
Figure f2 = new Box(); 
f2.display(); 
}
}

