package mefeteni;

 
public class Box extends Rectangle { 

public void display() {
System.out.print("Box");
}
}