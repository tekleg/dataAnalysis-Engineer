package projectTwo;

public class AudioItem {

	private String title;
	private double price;
	private int numSeconds;
	
	public AudioItem(String initialTitle, double initialPrice, int initialNumSeconds) {
		title = initialTitle;
		price = initialPrice;
		numSeconds = initialNumSeconds;
	}
	
	public String getTitle() {
		return title;
	}
	public double getPrice() {
		return price;
	}
	public int getNumSeconds() {
		return numSeconds;
	}

	public void setTitle(String newTitle) {
		if(!newTitle.isEmpty()) {
			title = newTitle;
		}
	}
	public void setPrice(double newPrice) {
		if(newPrice >= 0) {
			price = newPrice;
		}
	}
	public void setNumSeconds(int newNumSeconds) {
		if(newNumSeconds > 0) {
			numSeconds = newNumSeconds;
		}
	}
	
	public String toString() {
		return title + " ($" + price + "); " + numSeconds + " seconds";
	}
	
	public void playSample() {
		System.out.println("Playing first 15 seconds of " + title);
	}
	
}
