package projectTwo;

public class MidtermReview {

	public static void main(String[] args) {
		printPrimes(10);
		printPrimes(100);
		
		System.out.println(countCapitalLetters("Hello World"));
		int result = countCapitalLetters("MY NAME IS JESSICA!");

	}

	public static int countCapitalLetters(String text) {
		int numberOfCapital = 0;
		for(int i=0; i<text.length(); i++) {
			// option 1
			/*
			char letter = text.charAt(i);
			if(Character.isUpperCase(letter)) {
				numberOfCapital++;
			}
			*/
			
			// option 2
			String singleLetter = text.substring(i, i+1);
			String capitalLetter = singleLetter.toUpperCase();
			if(singleLetter.equals(capitalLetter)) {
				numberOfCapital++;
			}
		}
		return numberOfCapital;
	}
	
	public static void printPrimes(int maxValue) {

		// outer loop- the numbers i want to check
		for (int currentValue = 2; currentValue <= maxValue; currentValue++) {

			// all of this code gets repeated for each pass of the outer loop
			boolean prime = true;
			// inner loop- how i check that particular number
			for (int i = 2; i < currentValue; i++) {
				if (currentValue % i == 0) {
					prime = false;
				}
			}
			
			// if invoking a method for the inner loop, instead of writing directly
			//boolean prime = isPrime(currentValue);
			
			if (prime) {
				System.out.println(currentValue + " is prime");
			}
		}
	}
	
	private static boolean isPrime(int currentValue) {
		// local variable approach
		//boolean prime = true;

		// inner loop- how i check that particular number
		for (int i = 2; i < currentValue; i++) {
			if (currentValue % i == 0) {
				// prime = false;
				return false;
			}
		}
		
		// return prime;
		return true;

	}

}
