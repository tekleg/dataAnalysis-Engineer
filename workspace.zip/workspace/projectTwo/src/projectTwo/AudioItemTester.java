package projectTwo;

public class  {

	public static void main(String[] args) {
		 
		//getter
		AudioItem song1 = new AudioItem("Itsssy Bitsy Spider", 0.99, 120);
		AudioItem book1 = new AudioItem("Java Software Solutions", 59.99, 30000);
		
		 
		System.out.println(song1.getTitle());
		System.out.println(book1.getPrice());
		System.out.println(song1.getNumSeconds());
		
		//setter
		
		System.out.println(song1.getTitle());  //it needs to chance from the getter to setter
		song1.setTitle("Itsy Bitsy Spider");    // the parameter will be printed to replace the first one
		System.out.println(song1.getTitle());
		song1.setTitle("");                     //doing nothing  
		System.out.println(song1.getTitle());   //it  printed Itsy Bitsy Spider instead of Itsssy Bitsy Spider
		
		System.out.println(book1.getPrice());
		book1.setPrice(59.99-10);
		System.out.println(book1.getPrice());
		book1.setPrice(-10);
		System.out.println(book1.getPrice());
		book1.setPrice(0);
		System.out.println(book1.getPrice());
		
		//toString  method
		
		System.out.println(song1);
		System.out.println(book1);
		
		
		//other methods
		
		song1.playSample();
		book1.playSample();


	}

}
