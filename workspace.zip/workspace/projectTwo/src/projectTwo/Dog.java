       package projectTwo;

       public class Dog {
	 
		
		// instance data variables
		private String name;
		private int age;
		private double weight;
		private boolean vaccinated;
		
		// constructor  ///////////////////////
		public Dog(String initialName, int initialAge, double initialWeight,
				boolean initialVaccinated) {
			name = initialName;
			age = initialAge;
			weight = initialWeight;
			vaccinated = initialVaccinated;
			
		}
		
		// getters  ////////////////////////
		public String getName() {
			return name;
		}
		public int getAge() {
			return age;
		}
		public double getWeight() {
			return weight;
		}
		public boolean isVaccinated() {
			return vaccinated;
		}
		
		// setters ////////////////////////
		public void setName(String newName) {
			name = newName;
		}
		public void setAge(int newAge) {
			
			if(newAge >= 0) {
				age = newAge;
			} else {
				System.out.println("Age cannot be set to a negative value.");
			}
			/* another option  
			if(newAge < 0) {
				System.out.println("error");
			} else {
				age = newAge;
			}
			*/
			
		}
		
		public void setWeight(double newWeight) {
			if(newWeight > 0) {
				weight = newWeight;
			} else {
				System.out.println("Weight must be greater than zero.");
			}
		}
		
		public void setVaccinated(boolean newVaccinated) {
			vaccinated = newVaccinated;
		}
		
		//toString method   /////////////////
		public String toString() {
			String s = "Name: " + name +
					"\n\tAge: " + age +
					"\n\tWeight: " + weight +
					"\n\tVaccindated? " + vaccinated;
			return s;
		}
		
		public void walk() {
			System.out.println(name + " is out for a walk.");
		}
		public void feed() {
			System.out.println(name + " is being fed the right amount " +
					"for a " + weight + " pound dog.");
		}
		
		
		
		
		
	}


