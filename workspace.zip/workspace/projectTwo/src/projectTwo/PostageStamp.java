package projectTwo;

public class PostageStamp {

	//instant data variable//////////
	
	private double costPrice;
	private String descriptionOfFlagColor;
	 
	 
			 
	//constructor//////	

	public PostageStamp(double initialCostPrice, String initialDescriptionOfFlagColor  ){
	
	costPrice = initialCostPrice;
	descriptionOfFlagColor =  initialDescriptionOfFlagColor;
	 
	}
	//getters//////////
	public String getDescriptionOfFlagColor(){
	return descriptionOfFlagColor;
	}

	public double getCostPrice(){
	return costPrice;
	}
	 
 
	//setters////////

	public void setDescription(String newDescriptionOfFlagColor){
	descriptionOfFlagColor = newDescriptionOfFlagColor;
	System.out.println("The colors of the flag has changed now to " + descriptionOfFlagColor);

	}

	public void setCostPrice(double newCostPrice){
		
	if(newCostPrice >= 0){
	  costPrice = newCostPrice;}
	else{
	System.out.println("no cost set as negative.");
	}
	}

	 
	//toString method////////
	public String toString(){
	return " Cost Price:" + costPrice +
			"\ndescription" + descriptionOfFlagColor;
	
	//other method///
	public void makingOf (){
	 
	System.out.println(" The flag is made of paper");
	}
	


	 
	}

}
