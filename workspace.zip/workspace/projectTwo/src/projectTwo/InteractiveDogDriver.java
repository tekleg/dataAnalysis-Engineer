
package projectTwo;
import java.util.Scanner;
public class InteractiveDogDriver {

	public static void main(String[] args) {
Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the dog's name:");
		String dogName = scan.nextLine();
		
		System.out.println("How old?");
		int dogAge = Integer.parseInt(scan.nextLine());
		
		System.out.println("Weight?");
		double dogWeight = Double.parseDouble(scan.nextLine());
		
		System.out.println("Has " + dogName + " been vaccinated? y or n");
		String dogVaccinationString = scan.nextLine();
		boolean dogVaccinated;
		if(dogVaccinationString.equalsIgnoreCase("Y")) {
			dogVaccinated = true;
		} else {
			dogVaccinated = false;
		}
		
		Dog dog = new Dog(dogName, dogAge, dogWeight, dogVaccinated);
		
		System.out.println("Welcome to day care " + dog.getName() + "!");
		
		boolean keepCaringForDog = true;
		while(keepCaringForDog) {
			System.out.println("What action?");
			System.out.println("1 for walk");
			System.out.println("2 to feed");
			System.out.println("3 to view dog info");
			System.out.println("4 for dog birthday");
			
			int userChoice = Integer.parseInt(scan.nextLine());
			if(userChoice==1) {
				dog.walk();	 

	}

 }
}
}