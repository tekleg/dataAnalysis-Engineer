package projectTwo;

public class Array {

	public static void main(String[] args) {
		int count= 0;		
int number[]=new int [100]; 
for(int i=0; i<100; i++){
	count += i;

System.out.println(count);
	}

}
}