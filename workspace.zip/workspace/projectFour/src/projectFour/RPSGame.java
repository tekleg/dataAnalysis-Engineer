//Neil and Tekle

package projectFour;

import java.util.*;
public class RPSGame {
	public enum moves{ROCK,PAPER,SCISSORS};
	public enum outComes{USERWIN,COMPUTERWIN,TIE};
	private int numberOfComputerWins;
	private int numberOfUserWins;
    private int numberOfTies;
    private int bettingAmount;
    private int balance;
    
    public RPSGame(int bettingAmount ){
    	numberOfComputerWins = 0;
    	numberOfUserWins =0;
    	numberOfTies = 0;
    	this.bettingAmount=bettingAmount;
    	balance =0;
    }
    public int getCWins(){
    	return numberOfComputerWins;
    }
    public int getUWins(){
    	return numberOfUserWins;
    }
    public int getTies(){
    	return numberOfTies;
    }
   public int getbettingAmount(){
	    return bettingAmount;
   }
   public int  getBalance(){
	   return balance;
   }
   public  void setBettingAmount(int bettingAmount){
	      if(bettingAmount>=0){
	    	  this.bettingAmount=bettingAmount;
	      }else{
	    	  System.out.println("enter the valid betting amount");
	      }
   }
    public void setNumberOfComputerWins(int numberOfComputerWins){
    	if(numberOfComputerWins >=0){
    		this.numberOfComputerWins=numberOfComputerWins;
    	}
    }
    public void setNumberOfUserWins	(int numberOfUserWins){
    	if(numberOfUserWins >=0){
    	 this.numberOfUserWins=numberOfUserWins;
    	}
    
    }
    public void setNumberOfIies(int numberOfTies){
    	if(numberOfTies >=0){
    		this.numberOfTies=numberOfTies;
    	}
    }
public int addAmount(){
	return balance += bettingAmount;
}
public int  minusAmount(){
	     
	  return   balance -= bettingAmount;
	   
	  
}

    public moves generateComputerPlay(){
    	moves type = null;
  
    	Random  generator = new Random();
    	int randomNumber = generator.nextInt(3)+1 ;
    	  if (randomNumber ==1){
    		 type= moves.ROCK;
    	  }else if(randomNumber ==2){
     		 type= moves.PAPER;
           }else{
        	   type= moves.SCISSORS;
           }
    	  return type;
    }

 public outComes findWinner(moves userMove, moves computerMove ){
    	outComes winner=null;
    	
     if(userMove== moves.PAPER  ){
    	   if(computerMove==moves.ROCK){
    		  winner = outComes.USERWIN;
    		   numberOfUserWins++;
    		   addAmount();
    		   System.out.println("YOU WIN");
    	   }else if(computerMove==moves.SCISSORS){
    		   winner = outComes.COMPUTERWIN;
    		    numberOfComputerWins++;
    		    minusAmount();
    		    System.out.println("YOU LOSSE");
    	   }else if(computerMove==moves.PAPER){
    		   winner = outComes.TIE;
    		   numberOfTies++;
    		  System.out.println("IT's Tie");
    	   }
    	   
     }else if (userMove== moves.ROCK ){
    	  if(computerMove==moves.SCISSORS){
   		   winner = outComes.USERWIN;
   		   numberOfUserWins++;
   		   addAmount();
   		 System.out.println("YOU WIN");
   	     }else if(computerMove==moves.PAPER){
   		   winner = outComes.COMPUTERWIN;
   	    	numberOfComputerWins++;
   	    	minusAmount();
   		   System.out.println("YOU loss");
   	     }else if(computerMove==moves.ROCK){
   		   winner = outComes.TIE;
   		   numberOfTies++;
   		  System.out.println("IT's Tie");
   	     }
    	  
      } else if (userMove== moves.SCISSORS ){
    	 if(computerMove==moves.PAPER){
     		   winner = outComes.USERWIN;
     		   numberOfUserWins++;
     		  addAmount();
     		   System.out.println("YOU WIN");
     	     }else if(computerMove==moves.ROCK ){
     		   winner = outComes.COMPUTERWIN;
     		   numberOfComputerWins++;
     		    minusAmount();
     		  System.out.println("YOU LOSSE");
     	    }else if(computerMove==moves.SCISSORS){
     		   winner = outComes.TIE;
     		   numberOfTies++;
     		System.out.println("IT's Tie");
     	    }
    	 
          }
         return winner;
      }
    }


