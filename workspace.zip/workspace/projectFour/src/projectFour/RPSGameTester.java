//Neil and Tekle

package projectFour;

import java.util.*;
public class RPSGameTester {

	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		

		System.out.println("Welcome to Rock, Paper, Scissors!");
		System.out.println("Enter the bet amount (or enter '0'"+
		                    " to play for fun without betting)");
		
		String input = scan.nextLine();
		int betAmount = Integer.parseInt(input);
		
		RPSGame  game = new RPSGame(betAmount);
		
		
		RPSGame.moves computerMoves = game.generateComputerPlay();
	
		boolean gameAgain =true;
		while(gameAgain){
		System.out.println("To play, enter: ");
		System.out.println("	 'r' to play ROCK");
		System.out.println("	 'p' to play PAPER");
		System.out.println("	 's' to play SCISSORS");
		System.out.println("	 or any other character to quit. ");
		
		String choice = scan.nextLine();
		switch(choice.charAt(0)){
		    
		
		case 'r': 
		case 'R':
			
			System.out.println("You played ROCK");
			System.out.println("The computer played "+ computerMoves);
			game.findWinner(RPSGame.moves.ROCK, computerMoves);
		
			break;
		case 's': 
		case 'S': 
			System.out.println("You played SCISSORS");
			System.out.println("The computed played "+ computerMoves);
			game.findWinner(RPSGame.moves.SCISSORS, computerMoves);
			
			break;
		case 'p': 
		case 'P': 
			System.out.println("You played PAPER");
			System.out.println("The computed played "+ computerMoves);
			game.findWinner(RPSGame.moves.PAPER, computerMoves);
			break;
			
		default:
			    gameAgain =false;
			    
			break;
				
		    }
		  System.out.println("Ties: "+ game.getTies() +" Win:"+ game.getUWins()+
					" Losses: "+ game.getCWins());
		if(betAmount>0){
			   if(game.getBalance()>0){
			      System.out.println("Balance :"+ game.getBalance());
			   }else{
				   System.out.println("Balance : 0");
			   }
		 }
		}	
	     
		
	}
}

