import java.awt.*;
import javax.swing.*;
public class Authority {
public static void main (String[]args) {
	JFrame frame = new JFrame ("Authority");
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE );
	
	JPanel primary = new JPanel();
	primary.setBackground(Color.YELLOW);
	primary.setSize(200,100);
	//primary.setPreferredSize(new Dimenssion(200,100));
	
	
	Jlable label1 =new JLabel ("Question authoritiy.");
	Jlabel label2 =new Jlabel ("But raise your hand first.");
	
	primary.add(label1);
	 primary.add(label2);
	 
	 frame.getContentPane().add(primary );
	 frame.pack();
	 frame.setVisible(true);
}
}
