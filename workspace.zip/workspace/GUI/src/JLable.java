
public interface JLable {

}
