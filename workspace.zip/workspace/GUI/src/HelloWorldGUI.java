/* 
  	 * This file provides a GUI shell for you to edit. 
	 * Missing code marked with ??? must be replaced by you.
	 */
    import java.awt.*;
	import java.awt.event.*;
	import javax.swing.*;
 
	public class HelloWorldGUI extends JFrame{
	// private JLable helloLable;
		/*
		 * ??? Declare references to GUI components (labels, buttons, text fields, etc.), 
		 * objects (Strings, etc.), and primitive variables (int, double, etc.).
		 * 
		 */

		private Container contentPane; // a reference to the content pane of the JFrame

		// the constructor- has the same name as the class
		
		public HelloWorldGUI() {
			
			// invoke the super class constructor to construct the named window
			
			super(" Hello World! ");  //title bar text here

			// set the width and height of the window (in pixels)
			
			setSize(200,260);

			// get the content pane add a panel to it
			// set the background color of the panel (Color.??? constants)
			
			contentPane = getContentPane();
			
			JPanel mainPanel = new JPanel();
			
			mainPanel.setBackground(Color.cyan);
			
			contentPane.add(mainPanel);
			 
			//helloLable = new  JLable ("Hello World!");
			//mainpanel.add(helloLable);
			/*
			 * ??? For EACH GUI component: a) construct the component,
			 * b) customize it, if necessary, c) add it to the main panel, 
			 * and d) add a listener, if necessary
			 * 
			 */

			
			/*
			 * ??? Initialize any other object or primitive variables you declared.
			 * 
			 */

		}

		/*
		 * Listener Classes This is a shell that can be copied as many times as
		 * needed. You will need to change the class name for each class.
		 * 
		 */
	//	private class /*??? LISTENER CLASS NAME */ implements ActionListener {
	//		public void actionPerformed(ActionEvent event) {
				// ??? what should happen when the action is taken
		//	}
		//}

		public static void main(String args[]) {
		
	    EventQueue.invokeLater(new Runnable() {
					
					public void run() {
						
					// create an object of your class
				
						HelloWorldGUI frame = new HelloWorldGUI();   //CALL TO CONSTRUCTOR
						
						frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						
						frame.setVisible(true);
					}
				   });

			
		}
	}

